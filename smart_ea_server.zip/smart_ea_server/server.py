# -*- coding: utf-8 -*-
"""
لوحة تحكم Smart EA: سيرفر واحد يدير عدة بوتات تداول بنفس الوقت.

المميزات:
    - تسجيل دخول تيليجرام بالرقم (مع كشف تلقائي للتحقق الثنائي 2FA) أو بباركود
    - اختيار أي عدد من القنوات، كل وحدة تصير "بوت" مستقل
    - تحليل الرسائل (مسار سريع محلي + DeepSeek AI)
    - توليد ملف Expert Advisor جاهز لكل بوت (كل الإعدادات معبّاة تلقائياً)

التشغيل:
    pip install -r requirements.txt
    python3 server.py --port 5555 --password 'كلمة_المرور'

لتشغيل أكثر من نسخة على نفس السيرفر (لازم مجلد بيانات مستقل لكل وحدة):
    python3 server.py --port 5555 --password 'pass1' --data-dir data_1
    python3 server.py --port 5556 --password 'pass2' --data-dir data_2

    ثم افتح: http://SERVER_IP:5555
"""

import os
import json
import argparse
import time
import base64
import hashlib
import secrets
import asyncio
import logging
from io import BytesIO
from collections import deque
from contextlib import asynccontextmanager
from datetime import datetime, timezone

import qrcode
from fastapi import FastAPI, HTTPException, Request, Depends, Cookie
from fastapi.responses import HTMLResponse, PlainTextResponse, Response, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator
from telethon import TelegramClient, events
from telethon.errors import (
    SessionPasswordNeededError,
    PhoneCodeInvalidError,
    PhoneCodeExpiredError,
    PhoneNumberInvalidError,
    FloodWaitError,
)

import signal_parser as sp

# ============================== معاملات التشغيل ==============================
# تسمح بتشغيل أكثر من نسخة على نفس السيرفر، كل وحدة بمنفذ ومجلد بيانات مستقل:
#   python3 server.py --port 5555 --password 'كلمة_مرور' --data-dir data_1
#   python3 server.py --port 5556 --password 'كلمة_مرور' --data-dir data_2

_parser = argparse.ArgumentParser(description="Smart EA Dashboard", add_help=False)
_parser.add_argument("--port", "-p", type=int, default=None, help="منفذ السيرفر")
_parser.add_argument("--password", "-w", default=None, help="كلمة مرور لوحة التحكم")
_parser.add_argument("--data-dir", "-d", default=None, help="مجلد البيانات")
_parser.add_argument("--help", "-h", action="help", help="عرض المساعدة")
_args, _ = _parser.parse_known_args()

# ============================== إعدادات عامة ==============================

# الأولوية: معامل سطر الأوامر ثم متغير البيئة ثم الافتراضي
PORT = _args.port or int(os.environ.get("PORT", 5555))
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

_data_name = _args.data_dir or os.environ.get("DATA_DIR", "data")
DATA_DIR = _data_name if os.path.isabs(_data_name) else os.path.join(BASE_DIR, _data_name)

STATIC_DIR = os.path.join(BASE_DIR, "static")
TEMPLATES_DIR = os.path.join(BASE_DIR, "templates")
CONFIG_PATH = os.path.join(DATA_DIR, "config.json")
BOTS_PATH = os.path.join(DATA_DIR, "bots.json")
SESSION_NAME = os.path.join(DATA_DIR, "dashboard_session")
EA_TEMPLATE_PATH = os.path.join(TEMPLATES_DIR, "SmartTraderEA_template.mq5")

MAX_LOG_ENTRIES = 100
MAX_QUEUE_SIZE = 500

# لما روبوت يتصل لأول مرة (أو بعد إعادة تشغيل السيرفر)، بيلحق الأوامر اللي
# صدرت خلال هاي النافذة فقط. هيك ما يفوّت إشارة وصلت قبله بثواني، وبنفس
# الوقت ما ينفذ إشارات قديمة من ساعات.
FIRST_CONTACT_CATCHUP_SEC = 120

# أوامر فتح الصفقات ما تنفذ إذا صار عمرها أكثر من هيك (بالثواني).
# السبب: لو الروبوت كان مطفي أو انقطع، ما بدنا يدخل على إشارة قديمة السعر
# تغير عنها. أوامر الإغلاق/تعديل الوقف ما تتأثر لأنها إدارة صفقات قائمة.
MAX_OPEN_SIGNAL_AGE_SEC = 120

# رابط التواصل الافتراضي (يظهر تلقائياً بخانة "رابط التواصل" باللوحة أول مرة،
# تقدر تغيّره من اللوحة نفسها بأي وقت بدون لمس الكود)
DEFAULT_TELEGRAM_LINK = "https://t.me/rsvx7"

# ---- حماية لوحة التحكم ----
# كلمة مرور اللوحة تتحدد من متغير البيئة ADMIN_PASSWORD عند التشغيل.
# مثال: ADMIN_PASSWORD='كلمة_قوية' python3 server.py
ADMIN_PASSWORD = (_args.password or os.environ.get("ADMIN_PASSWORD", "")).strip()
SESSION_COOKIE = "smart_ea_session"
SESSION_TTL = 60 * 60 * 24 * 7  # أسبوع

# جلسات اللوحة النشطة: token -> وقت الانتهاء
admin_sessions: dict[str, float] = {}

os.makedirs(DATA_DIR, exist_ok=True)

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(message)s")
log = logging.getLogger("server")

# ============================== حالة عامة بالذاكرة ==============================

telethon_client: TelegramClient | None = None

# حالة تسجيل الدخول بالرقم (بين إرسال الكود والتحقق منه)
phone_login = {"phone": None, "code_hash": None, "needs_password": False}

# حالة تسجيل الدخول بالباركود
qr_state = {"qr_login": None, "error": None}

# bots[bot_id] = {
#   "id", "token", "chat_id", "chat_title", "lot", "trades_count", "fallback_sl",
#   "magic", "licenses": [{"account","expires","note"}],
#   "commands": deque[(seq, line)],   # سجل الأوامر بترتيب تسلسلي
#   "seq": int,                        # عداد تسلسلي
#   "cursors": {account: last_seq},    # آخر أمر استلمه كل حساب (لكل حساب مؤشر مستقل)
#   "log": deque,
# }
bots: dict[str, dict] = {}
bot_handlers: dict[str, object] = {}


# ============================== تحميل/حفظ الملفات ==============================

def load_config() -> dict:
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError) as e:
            log.error("تعذر قراءة ملف الإعدادات: %s", e)
    return {}


def save_config(cfg: dict):
    tmp = CONFIG_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    os.replace(tmp, CONFIG_PATH)


def load_saved_bots() -> list:
    if os.path.exists(BOTS_PATH):
        try:
            with open(BOTS_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError) as e:
            log.error("تعذر قراءة ملف البوتات: %s", e)
    return []


def persist_bots():
    data = [
        {
            "id": b["id"], "token": b["token"],
            "chat_id": b["chat_id"], "chat_title": b["chat_title"],
            "lot": b["lot"], "trades_count": b["trades_count"],
            "fallback_sl": b["fallback_sl"], "magic": b["magic"],
            "margin_usage": b.get("margin_usage", 20.0),
            "max_trades": b.get("max_trades", 0),
            "min_margin_level": b.get("min_margin_level", 300.0),
            "licenses": b.get("licenses", []),
        }
        for b in bots.values()
    ]
    tmp = BOTS_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, BOTS_PATH)


# ============================== نماذج الطلبات ==============================

class ConfigIn(BaseModel):
    api_id: int = Field(gt=0)
    api_hash: str = Field(min_length=8)
    deepseek_api_key: str = Field(min_length=8)
    symbol_map: dict[str, str] | None = None


class PhoneIn(BaseModel):
    phone: str = Field(min_length=5, max_length=25)


class CodeIn(BaseModel):
    code: str = Field(min_length=3, max_length=10)


class PasswordIn(BaseModel):
    password: str = Field(min_length=1)


class NewBotIn(BaseModel):
    chat_id: str
    chat_title: str
    lot: float = Field(default=0.01, gt=0, le=100)
    trades_count: int = Field(default=1, ge=0, le=100)   # 0 = تلقائي حسب الرافعة
    fallback_sl: float = Field(default=0.5, ge=0, le=50)
    margin_usage: float = Field(default=20.0, gt=0, le=100)
    max_trades: int = Field(default=0, ge=0, le=200)
    min_margin_level: float = Field(default=300.0, ge=0, le=10000)


class UpdateBotIn(BaseModel):
    lot: float = Field(gt=0, le=100)
    trades_count: int = Field(ge=0, le=100)
    fallback_sl: float = Field(ge=0, le=50)
    margin_usage: float = Field(default=20.0, gt=0, le=100)
    max_trades: int = Field(default=0, ge=0, le=200)
    min_margin_level: float = Field(default=300.0, ge=0, le=10000)


def _validate_date(v: str) -> str:
    v = (v or "").strip()
    try:
        datetime.strptime(v, "%Y-%m-%d")
    except ValueError:
        raise ValueError("صيغة التاريخ لازم تكون YYYY-MM-DD مثل 2026-12-31")
    return v


class LicenseIn(BaseModel):
    account: str = Field(min_length=1, max_length=32)
    expires: str
    note: str = Field(default="", max_length=60)

    @field_validator("expires")
    @classmethod
    def check_expires(cls, v):
        return _validate_date(v)

    @field_validator("account")
    @classmethod
    def check_account(cls, v):
        v = v.strip()
        if not v.isdigit():
            raise ValueError("رقم الحساب لازم يكون أرقام فقط")
        return v


class LicenseUpdateIn(BaseModel):
    expires: str
    note: str = Field(default="", max_length=60)

    @field_validator("expires")
    @classmethod
    def check_expires(cls, v):
        return _validate_date(v)


class TelegramLinkIn(BaseModel):
    telegram_link: str = Field(default="", max_length=200)


# ============================== معالجة رسائل تيليجرام ==============================

async def handle_incoming_message(bot_id: str, text: str, loop):
    bot = bots.get(bot_id)
    if bot is None:
        return

    cfg = load_config()
    symbol_map = cfg.get("symbol_map") or sp.DEFAULT_SYMBOL_MAP

    # الذكاء الاصطناعي هو المحلل الأساسي لكل الرسائل - بيفهم الفروق الدقيقة
    # (تعزيز، إغلاق أول صفقة، خطة مقابل أمر تنفيذ) اللي الكلمات المفتاحية
    # لحالها ما بتلتقطها.
    cmd, ai_error = None, None
    try:
        cmd, ai_error = await loop.run_in_executor(
            None, sp.ai_parse, text, cfg.get("deepseek_api_key", ""), symbol_map
        )
    except Exception as e:
        log.error("خطأ أثناء تحليل AI: %s", e)
        ai_error = str(e)

    source = "ذكاء اصطناعي"

    # شبكة أمان: لو الذكاء الاصطناعي فشل (رصيد/شبكة) أو فاته أمر حرج،
    # منستخدم التحليل المحلي عشان أوامر الإغلاق ما تضيع أبداً
    if cmd is None:
        fallback = sp.fast_parse(text, symbol_map)
        if fallback:
            cmd = fallback
            source = "احتياطي محلي" if ai_error else "محلي"
            if ai_error:
                log.warning("الذكاء الاصطناعي فشل - تم استخدام التحليل المحلي: %s", cmd)

    if ai_error and cmd is None:
        status = "خطأ AI"
    elif cmd:
        status = source
    else:
        status = "تجاهل"

    entry = {
        "time": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "text": text[:200],
        "source": status,
        "command": None,
        "error": ai_error if cmd is None else None,
    }

    if cmd:
        line = sp.cmd_to_line(cmd)
        if line:
            bot["seq"] += 1
            bot["commands"].append((bot["seq"], line, time.time()))
            entry["command"] = line
            log.info("[%s] أمر (%s): %s", bot["chat_title"], source, line)

    bot["log"].appendleft(entry)


def register_bot_handler(bot_id: str, chat_entity):
    loop = asyncio.get_event_loop()

    async def handler(event):
        try:
            text = event.raw_text
            if not text or len(text.strip()) < 2:
                return
            await handle_incoming_message(bot_id, text, loop)
        except Exception as e:
            log.error("خطأ بمعالجة رسالة للبوت %s: %s", bot_id, e)

    telethon_client.add_event_handler(handler, events.NewMessage(chats=chat_entity))
    bot_handlers[bot_id] = handler


# ============================== عميل تيليجرام ==============================

CONNECT_TIMEOUT = 8  # ثانية - عشان ما يعلّق السيرفر لو تيليجرام مو واصل


async def ensure_client() -> TelegramClient:
    global telethon_client
    cfg = load_config()
    if not cfg.get("api_id") or not cfg.get("api_hash"):
        raise HTTPException(400, "لازم تضبط API ID و API Hash أولاً")

    if telethon_client is None:
        telethon_client = TelegramClient(
            SESSION_NAME, cfg["api_id"], cfg["api_hash"],
            connection_retries=2, retry_delay=1, timeout=10,
        )

    if not telethon_client.is_connected():
        try:
            await asyncio.wait_for(telethon_client.connect(), timeout=CONNECT_TIMEOUT)
        except asyncio.TimeoutError:
            raise HTTPException(
                503, "تعذر الاتصال بسيرفرات تيليجرام - تأكد من اتصال السيرفر بالإنترنت"
            )
        except Exception as e:
            raise HTTPException(503, f"تعذر الاتصال بتيليجرام: {e}")

    return telethon_client


# ============================== دورة حياة التطبيق ==============================

async def on_startup():
    log.info("=" * 60)
    log.info("المنفذ: %s  |  مجلد البيانات: %s", PORT, DATA_DIR)
    if ADMIN_PASSWORD:
        log.info("لوحة التحكم محمية بكلمة مرور ✓")
    else:
        log.warning("=" * 68)
        log.warning("تحذير أمني: لوحة التحكم مفتوحة بدون كلمة مرور!")
        log.warning("أي حد يعرف رابط السيرفر يقدر يفتحها ويتحكم ببوتاتك.")
        log.warning("شغّل السيرفر هيك بدلها:")
        log.warning("    ADMIN_PASSWORD='كلمة_مرور_قوية' python3 server.py")
        log.warning("=" * 68)

    cfg = load_config()
    if not cfg.get("api_id") or not cfg.get("api_hash"):
        log.info("لا يوجد إعداد بعد - افتح لوحة التحكم بالمتصفح")
        return
    try:
        client = await ensure_client()
    except Exception as e:
        log.error("تعذر تهيئة عميل تيليجرام: %s", e)
        return

    try:
        authorized = await asyncio.wait_for(client.is_user_authorized(), timeout=15)
    except Exception as e:
        log.error("تعذر التحقق من حالة تسجيل الدخول: %s", e)
        return

    if not authorized:
        log.info("لسا ما سجلت دخول تيليجرام - افتح لوحة التحكم بالمتصفح")
        return

    try:
        await asyncio.wait_for(client.get_dialogs(), timeout=60)
    except Exception as e:
        log.error("تعذر جلب المحادثات: %s", e)
        return

    for b in load_saved_bots():
        try:
            entity = await client.get_entity(int(b["chat_id"]))
        except Exception as e:
            log.error("تعذر إعادة ربط البوت %s (%s): %s", b["id"], b.get("chat_title"), e)
            continue
        bots[b["id"]] = {
            "id": b["id"], "token": b["token"],
            "chat_id": b["chat_id"], "chat_title": b["chat_title"],
            "lot": b.get("lot", 0.01),
            "trades_count": b.get("trades_count", 1),
            "fallback_sl": b.get("fallback_sl", 0.5),
            "margin_usage": b.get("margin_usage", 20.0),
            "max_trades": b.get("max_trades", 0),
            "min_margin_level": b.get("min_margin_level", 300.0),
            "magic": b.get("magic", 987654),
            "licenses": b.get("licenses", []),
            "commands": deque(maxlen=MAX_QUEUE_SIZE),
            "seq": 0,
            "cursors": {},
            "last_seen": {},
            "denied": {},
            "delivered": {},
            "log": deque(maxlen=MAX_LOG_ENTRIES),
        }
        register_bot_handler(b["id"], entity)
        log.info("أُعيد ربط البوت: %s (%s)", b["id"], b["chat_title"])

        # تنبيه واضح عن التراخيص المنتهية أو اللي قربت تنتهي
        for lic in b.get("licenses", []):
            d = _days_left(lic)
            if d is None:
                continue
            if d < 0:
                log.warning(
                    "⚠️  ترخيص منتهي: الحساب %s (%s) انتهى من %d يوم - الروبوت عنده متوقف!",
                    lic["account"], lic.get("note", ""), abs(d),
                )
            elif d <= 3:
                log.warning(
                    "⚠️  ترخيص قرب ينتهي: الحساب %s (%s) باقي %d يوم",
                    lic["account"], lic.get("note", ""), d,
                )


async def health_monitor():
    """يراقب الروبوتات: يسجّل تنبيه لو روبوت مرخّص وقف يتصل فجأة."""
    warned: set = set()
    while True:
        await asyncio.sleep(60)
        now = time.time()
        for b in bots.values():
            for lic in b.get("licenses", []):
                acc = lic["account"]
                key = f"{b['id']}:{acc}"
                seen = b.get("last_seen", {}).get(acc)
                if seen is None:
                    continue
                silent = now - seen
                if silent > 120 and key not in warned:
                    warned.add(key)
                    log.warning(
                        "⚠️  الروبوت على الحساب %s (%s) وقف يتصل من %d ثانية - "
                        "تأكد إن MT5 شغالة و Algo Trading مفعّل والرابط مضاف بـ Allow WebRequest",
                        acc, lic.get("note", ""), int(silent),
                    )
                elif silent <= 120 and key in warned:
                    warned.discard(key)
                    log.info("✓ الروبوت على الحساب %s رجع يتصل", acc)


@asynccontextmanager
async def lifespan(app: FastAPI):
    await on_startup()
    monitor = asyncio.create_task(health_monitor())
    yield
    monitor.cancel()
    if telethon_client and telethon_client.is_connected():
        await telethon_client.disconnect()


app = FastAPI(title="Smart EA Dashboard", lifespan=lifespan)


# ============================== حماية لوحة التحكم ==============================

def _cleanup_sessions():
    now = time.time()
    for tok in [t for t, exp in admin_sessions.items() if exp < now]:
        admin_sessions.pop(tok, None)


def require_admin(request: Request):
    """
    حماية كل نقاط اللوحة. نقطة الـEA (commands/next) مستثناة لأنها محمية
    بتوكن البوت الخاص فيها.
    لو ما فيه ADMIN_PASSWORD مضبوط، السيرفر يشتغل بدون حماية (وضع غير آمن،
    مناسب فقط لو السيرفر على شبكة خاصة/VPN مغلقة).
    """
    if not ADMIN_PASSWORD:
        return True

    _cleanup_sessions()
    token = request.cookies.get(SESSION_COOKIE)
    if token and admin_sessions.get(token, 0) > time.time():
        return True
    raise HTTPException(401, "لازم تسجل دخول للوحة التحكم")


class AdminLoginIn(BaseModel):
    password: str = Field(min_length=1)


@app.get("/api/auth/status")
async def auth_status(request: Request):
    """تخبر الواجهة هل فيه حماية مفعّلة وهل المستخدم داخل."""
    if not ADMIN_PASSWORD:
        return {"protected": False, "authenticated": True}
    _cleanup_sessions()
    token = request.cookies.get(SESSION_COOKIE)
    ok = bool(token and admin_sessions.get(token, 0) > time.time())
    return {"protected": True, "authenticated": ok}


@app.post("/api/auth/login")
async def admin_login(data: AdminLoginIn):
    if not ADMIN_PASSWORD:
        return {"ok": True, "protected": False}

    # مقارنة ثابتة الزمن لمنع تخمين كلمة المرور بقياس الوقت
    if not secrets.compare_digest(data.password, ADMIN_PASSWORD):
        await asyncio.sleep(1)  # تبطيء بسيط ضد التخمين المتكرر
        raise HTTPException(401, "كلمة المرور غير صحيحة")

    token = secrets.token_urlsafe(32)
    admin_sessions[token] = time.time() + SESSION_TTL

    resp = JSONResponse({"ok": True})
    resp.set_cookie(
        SESSION_COOKIE, token,
        max_age=SESSION_TTL, httponly=True, samesite="lax",
    )
    return resp


@app.post("/api/auth/logout")
async def admin_logout(request: Request):
    token = request.cookies.get(SESSION_COOKIE)
    if token:
        admin_sessions.pop(token, None)
    resp = JSONResponse({"ok": True})
    resp.delete_cookie(SESSION_COOKIE)
    return resp


# ============================== الإعدادات ==============================

@app.get("/api/config")
async def get_config(_admin=Depends(require_admin)):
    cfg = load_config()
    return {
        "configured": bool(
            cfg.get("api_id") and cfg.get("api_hash") and cfg.get("deepseek_api_key")
        ),
        "symbol_map": cfg.get("symbol_map") or sp.DEFAULT_SYMBOL_MAP,
        "telegram_link": cfg.get("telegram_link") or DEFAULT_TELEGRAM_LINK,
    }


@app.put("/api/config/telegram_link")
async def set_telegram_link(data: TelegramLinkIn, _admin=Depends(require_admin)):
    """رابط التواصل اللي يظهر للمستخدم لو حسابه غير مرخّص أو اشتراكه منتهي."""
    cfg = load_config()
    if not cfg:
        raise HTTPException(400, "لازم تكمل الإعداد الأولي أولاً")
    cfg["telegram_link"] = data.telegram_link.strip()
    save_config(cfg)
    return {"ok": True}


@app.post("/api/config")
async def set_config(cfg_in: ConfigIn, _admin=Depends(require_admin)):
    global telethon_client
    old = load_config()
    save_config({
        "api_id": cfg_in.api_id,
        "api_hash": cfg_in.api_hash.strip(),
        "deepseek_api_key": cfg_in.deepseek_api_key.strip(),
        "symbol_map": cfg_in.symbol_map or sp.DEFAULT_SYMBOL_MAP,
        "telegram_link": old.get("telegram_link") or DEFAULT_TELEGRAM_LINK,
    })
    # نلغي أي عميل قديم عشان يُعاد بناؤه بالمفاتيح الجديدة
    if telethon_client is not None:
        try:
            if telethon_client.is_connected():
                await telethon_client.disconnect()
        except Exception:
            pass
        telethon_client = None
    return {"ok": True}


@app.put("/api/config/symbols")
async def update_symbols(symbol_map: dict[str, str], _admin=Depends(require_admin)):
    cfg = load_config()
    if not cfg:
        raise HTTPException(400, "لازم تكمل الإعداد الأولي أولاً")
    cfg["symbol_map"] = symbol_map
    save_config(cfg)
    return {"ok": True}


# ============================== تسجيل الدخول ==============================

@app.get("/api/telegram/status")
async def telegram_status(_admin=Depends(require_admin)):
    cfg = load_config()
    if not cfg.get("api_id"):
        return {"logged_in": False, "configured": False}
    try:
        client = await ensure_client()
        authed = await asyncio.wait_for(client.is_user_authorized(), timeout=15)
    except HTTPException as e:
        return {"logged_in": False, "configured": True, "error": e.detail}
    except Exception as e:
        return {"logged_in": False, "configured": True, "error": str(e)}

    me_name = None
    if authed:
        try:
            me = await client.get_me()
            me_name = me.first_name if me else None
        except Exception:
            pass

    return {
        "logged_in": authed,
        "configured": True,
        "needs_password": phone_login["needs_password"],
        "me": me_name,
    }


@app.post("/api/telegram/phone/send_code")
async def send_code(data: PhoneIn, _admin=Depends(require_admin)):
    client = await ensure_client()
    if await client.is_user_authorized():
        return {"already_logged_in": True}

    phone = data.phone.strip().replace(" ", "")
    if not phone.startswith("+"):
        phone = "+" + phone

    try:
        sent = await client.send_code_request(phone)
    except PhoneNumberInvalidError:
        raise HTTPException(400, "رقم الهاتف غير صحيح - تأكد إنه بالصيغة الدولية مثل ‎+90551...")
    except FloodWaitError as e:
        raise HTTPException(429, f"محاولات كثيرة - انتظر {e.seconds} ثانية وحاول مرة ثانية")
    except Exception as e:
        raise HTTPException(400, f"تعذر إرسال الكود: {e}")

    phone_login["phone"] = phone
    phone_login["code_hash"] = sent.phone_code_hash
    phone_login["needs_password"] = False
    log.info("تم إرسال كود التحقق للرقم %s", phone)
    return {"ok": True}


@app.post("/api/telegram/phone/verify_code")
async def verify_code(data: CodeIn, _admin=Depends(require_admin)):
    client = await ensure_client()
    if not phone_login["phone"] or not phone_login["code_hash"]:
        raise HTTPException(400, "لازم تطلب كود التحقق أولاً")

    code = data.code.strip()
    try:
        await client.sign_in(
            phone=phone_login["phone"],
            code=code,
            phone_code_hash=phone_login["code_hash"],
        )
    except SessionPasswordNeededError:
        # الحساب محمي بتحقق ثنائي - نطلب كلمة المرور من الواجهة
        phone_login["needs_password"] = True
        log.info("الحساب محمي بتحقق ثنائي - بانتظار كلمة المرور")
        return {"needs_password": True}
    except PhoneCodeInvalidError:
        raise HTTPException(400, "الكود غير صحيح - تأكد منه وحاول مرة ثانية")
    except PhoneCodeExpiredError:
        raise HTTPException(400, "انتهت صلاحية الكود - اطلب كود جديد")
    except Exception as e:
        raise HTTPException(400, f"فشل التحقق: {e}")

    await _post_login_setup()
    return {"logged_in": True}


@app.post("/api/telegram/phone/verify_password")
async def verify_password(data: PasswordIn, _admin=Depends(require_admin)):
    client = await ensure_client()
    try:
        await client.sign_in(password=data.password)
    except Exception as e:
        raise HTTPException(400, f"كلمة المرور غير صحيحة: {e}")

    phone_login["needs_password"] = False
    await _post_login_setup()
    return {"logged_in": True}


@app.post("/api/telegram/qr")
async def telegram_qr(_admin=Depends(require_admin)):
    client = await ensure_client()
    if await client.is_user_authorized():
        return {"already_logged_in": True}

    qr = await client.qr_login()
    qr_state["qr_login"] = qr
    qr_state["error"] = None

    img = qrcode.make(qr.url)
    buf = BytesIO()
    img.save(buf, format="PNG")
    b64 = base64.b64encode(buf.getvalue()).decode()

    async def wait_for_qr():
        try:
            await qr.wait()
            await _post_login_setup()
        except SessionPasswordNeededError:
            phone_login["needs_password"] = True
        except Exception as e:
            qr_state["error"] = str(e)

    asyncio.create_task(wait_for_qr())
    return {"qr_image_base64": b64}


async def _post_login_setup():
    """بعد نجاح تسجيل الدخول: نجيب المحادثات لتخزين access hash."""
    phone_login["phone"] = None
    phone_login["code_hash"] = None
    try:
        client = await ensure_client()
        await client.get_dialogs()
        log.info("تم تسجيل الدخول بنجاح")
    except Exception as e:
        log.error("خطأ بعد تسجيل الدخول: %s", e)


@app.post("/api/telegram/logout")
async def telegram_logout(_admin=Depends(require_admin)):
    global telethon_client
    if telethon_client:
        try:
            await telethon_client.log_out()
        except Exception as e:
            log.error("خطأ بتسجيل الخروج: %s", e)
        telethon_client = None
    bots.clear()
    bot_handlers.clear()
    persist_bots()
    return {"ok": True}


# ============================== القنوات ==============================

@app.get("/api/telegram/dialogs")
async def telegram_dialogs(_admin=Depends(require_admin)):
    client = await ensure_client()
    if not await client.is_user_authorized():
        raise HTTPException(400, "لازم تسجل دخول تيليجرام أولاً")

    result = []
    try:
        async for dialog in client.iter_dialogs():
            entity = dialog.entity
            username = getattr(entity, "username", None)
            result.append({
                "id": str(dialog.id),
                "name": dialog.name or "?",
                "username": f"@{username}" if username else None,
            })
    except Exception as e:
        raise HTTPException(500, f"تعذر جلب القنوات: {e}")
    return result


# ============================== البوتات ==============================

def _is_auto(bot: dict) -> bool:
    """عدد الصفقات = 0 باللوحة يعني الوضع التلقائي حسب الرافعة."""
    return int(bot.get("trades_count", 1)) == 0


def _license_status(lic: dict) -> str:
    """حالة الترخيص: نشط / قرب ينتهي / منتهي"""
    try:
        exp = datetime.strptime(lic["expires"], "%Y-%m-%d").date()
    except (ValueError, KeyError):
        return "غير صالح"
    today = datetime.now(timezone.utc).date()
    if today > exp:
        return "منتهي"
    if (exp - today).days <= 3:
        return "قرب ينتهي"
    return "نشط"


def _days_left(lic: dict):
    try:
        exp = datetime.strptime(lic["expires"], "%Y-%m-%d").date()
    except (ValueError, KeyError):
        return None
    return (exp - datetime.now(timezone.utc).date()).days


def _bot_public(b: dict) -> dict:
    now = time.time()
    licensed_accounts = {l["account"] for l in b.get("licenses", [])}
    licenses = []
    for lic in b.get("licenses", []):
        acc = lic["account"]
        cursor = b["cursors"].get(acc)
        seen = b.get("last_seen", {}).get(acc)
        # نعتبره متصل فعلاً لو اتصل خلال آخر 30 ثانية (الـEA يسأل كل ثانية)
        online = seen is not None and (now - seen) <= 30
        licenses.append({
            **lic,
            "status": _license_status(lic),
            "days_left": _days_left(lic),
            "online": online,
            "last_seen_ago": int(now - seen) if seen else None,
            "delivered": b.get("delivered", {}).get(acc, 0),
            "pending": sum(1 for s, _l, _t in b["commands"] if s > (cursor or 0)),
        })

    # حسابات حاولت تتصل بس مو مرخّصة إطلاقاً - مؤشر قوي إن ملف EA
    # انثبت على حساب غير اللي اتولّد له
    unknown = [
        {"account": acc, "count": d["count"], "ago": int(now - d["last"])}
        for acc, d in b.get("denied", {}).items()
        if acc not in licensed_accounts
    ]

    return {
        "id": b["id"], "token": b["token"],
        "chat_title": b["chat_title"], "chat_id": b["chat_id"],
        "lot": b["lot"], "trades_count": b["trades_count"],
        "fallback_sl": b["fallback_sl"],
        "margin_usage": b.get("margin_usage", 20.0),
        "max_trades": b.get("max_trades", 0),
        "min_margin_level": b.get("min_margin_level", 300.0),
        "licenses": licenses,
        "unknown_attempts": unknown,
        "total_commands": b["seq"],
    }


@app.get("/api/bots")
async def list_bots(_admin=Depends(require_admin)):
    return [_bot_public(b) for b in bots.values()]


@app.post("/api/bots")
async def create_bot(new_bot: NewBotIn, _admin=Depends(require_admin)):
    client = await ensure_client()
    if not await client.is_user_authorized():
        raise HTTPException(400, "لازم تسجل دخول تيليجرام أولاً")

    # منع إضافة نفس القناة مرتين
    for b in bots.values():
        if b["chat_id"] == new_bot.chat_id:
            raise HTTPException(400, "هاي القناة مضافة أصلاً")

    try:
        entity = await client.get_entity(int(new_bot.chat_id))
    except (ValueError, TypeError) as e:
        raise HTTPException(400, f"تعذر العثور على المحادثة: {e}")
    except Exception as e:
        raise HTTPException(400, f"خطأ بجلب المحادثة: {e}")

    bot_id = secrets.token_hex(4)
    bots[bot_id] = {
        "id": bot_id,
        "token": secrets.token_urlsafe(24),
        "chat_id": new_bot.chat_id,
        "chat_title": new_bot.chat_title,
        "lot": new_bot.lot,
        "trades_count": new_bot.trades_count,
        "fallback_sl": new_bot.fallback_sl,
        "margin_usage": new_bot.margin_usage,
        "max_trades": new_bot.max_trades,
        "min_margin_level": new_bot.min_margin_level,
        "magic": secrets.randbelow(900000) + 100000,  # ماجيك فريد لكل بوت
        "licenses": [],
        "commands": deque(maxlen=MAX_QUEUE_SIZE),
        "seq": 0,
        "cursors": {},
        "last_seen": {},
        "denied": {},
        "delivered": {},
        "log": deque(maxlen=MAX_LOG_ENTRIES),
    }
    register_bot_handler(bot_id, entity)
    persist_bots()
    log.info("بوت جديد: %s -> %s", bot_id, new_bot.chat_title)
    return _bot_public(bots[bot_id])


@app.put("/api/bots/{bot_id}")
async def update_bot(bot_id: str, data: UpdateBotIn, _admin=Depends(require_admin)):
    bot = bots.get(bot_id)
    if bot is None:
        raise HTTPException(404, "بوت غير موجود")
    bot["lot"] = data.lot
    bot["trades_count"] = data.trades_count
    bot["fallback_sl"] = data.fallback_sl
    bot["margin_usage"] = data.margin_usage
    bot["max_trades"] = data.max_trades
    bot["min_margin_level"] = data.min_margin_level
    persist_bots()
    return _bot_public(bot)


@app.delete("/api/bots/{bot_id}")
async def delete_bot(bot_id: str, _admin=Depends(require_admin)):
    if bot_id not in bots:
        raise HTTPException(404, "بوت غير موجود")
    handler = bot_handlers.pop(bot_id, None)
    if handler and telethon_client:
        try:
            telethon_client.remove_event_handler(handler)
        except Exception as e:
            log.error("خطأ بإزالة الـhandler: %s", e)
    del bots[bot_id]
    persist_bots()
    return {"ok": True}


@app.get("/api/bots/{bot_id}/log")
async def bot_log(bot_id: str, _admin=Depends(require_admin)):
    bot = bots.get(bot_id)
    if bot is None:
        raise HTTPException(404, "بوت غير موجود")
    return list(bot["log"])


# ============================== توليد ملف الـEA ==============================

@app.get("/api/bots/{bot_id}/ea")
async def download_ea(bot_id: str, server_url: str = "", account: str = "",
                      _admin=Depends(require_admin)):
    bot = bots.get(bot_id)
    if bot is None:
        raise HTTPException(404, "بوت غير موجود")

    if not os.path.exists(EA_TEMPLATE_PATH):
        raise HTTPException(500, "قالب الـEA غير موجود على السيرفر")

    url = (server_url or "").strip().rstrip("/")
    if not url:
        raise HTTPException(400, "لازم تحديد رابط السيرفر")

    account = (account or "").strip()
    if not account:
        raise HTTPException(400, "لازم تحديد رقم الحساب اللي رح يشتغل عليه الـEA")

    lic = next((l for l in bot["licenses"] if l["account"] == account), None)
    if lic is None:
        raise HTTPException(400, "ما فيه ترخيص لهاد الحساب - أضفه أولاً من قسم التراخيص")

    with open(EA_TEMPLATE_PATH, "r", encoding="utf-8") as f:
        template = f.read()

    cfg = load_config()
    replacements = {
        "__BOT_TITLE__": bot["chat_title"],
        "__SERVER_URL__": url,
        "__BOT_ID__": bot["id"],
        "__BOT_TOKEN__": bot["token"],
        "__FIXED_LOT__": str(bot["lot"]),
        "__SIZING_MODE__": "MODE_AUTO" if _is_auto(bot) else "MODE_FIXED",
        "__TRADES_COUNT__": str(bot["trades_count"] if not _is_auto(bot) else 1),
        "__MAGIC_NUMBER__": str(bot["magic"]),
        "__FALLBACK_SL__": str(bot["fallback_sl"]),
        "__MARGIN_USAGE__": str(bot.get("margin_usage", 20.0)),
        "__MAX_TRADES__": str(bot.get("max_trades", 0)),
        "__MIN_MARGIN_LEVEL__": str(bot.get("min_margin_level", 300.0)),
        "__SLIPPAGE__": "20",
        "__POLL_INTERVAL__": "1",
        "__ALLOWED_ACCOUNT__": account,
        "__EXPIRY_DATE__": lic["expires"],
        "__CONTACT_LINK__": cfg.get("telegram_link") or DEFAULT_TELEGRAM_LINK,
    }
    content = template
    for key, value in replacements.items():
        content = content.replace(key, value)

    # تأكيد ما ضل أي placeholder غير معبّى
    if any(k in content for k in replacements):
        raise HTTPException(500, "خطأ بتوليد ملف الـEA")

    filename = f"SmartTraderEA_{account}.mq5"

    return Response(
        content=content.encode("utf-8"),
        media_type="text/plain; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


# ============================== التراخيص ==============================

@app.post("/api/bots/{bot_id}/licenses")
async def add_license(bot_id: str, data: LicenseIn, _admin=Depends(require_admin)):
    bot = bots.get(bot_id)
    if bot is None:
        raise HTTPException(404, "بوت غير موجود")

    account = data.account.strip()
    if any(l["account"] == account for l in bot["licenses"]):
        raise HTTPException(400, "رقم الحساب مضاف أصلاً لهاد البوت")

    bot["licenses"].append({
        "account": account,
        "expires": data.expires,
        "note": data.note.strip(),
    })
    persist_bots()
    log.info("[%s] ترخيص جديد: %s حتى %s", bot["chat_title"], account, data.expires)
    return _bot_public(bot)


@app.put("/api/bots/{bot_id}/licenses/{account}")
async def update_license(bot_id: str, account: str, data: LicenseUpdateIn,
                         _admin=Depends(require_admin)):
    bot = bots.get(bot_id)
    if bot is None:
        raise HTTPException(404, "بوت غير موجود")

    lic = next((l for l in bot["licenses"] if l["account"] == account), None)
    if lic is None:
        raise HTTPException(404, "الترخيص غير موجود")

    lic["expires"] = data.expires
    lic["note"] = data.note.strip()
    persist_bots()
    log.info("[%s] تحديث ترخيص %s حتى %s", bot["chat_title"], account, data.expires)
    return _bot_public(bot)


@app.delete("/api/bots/{bot_id}/licenses/{account}")
async def delete_license(bot_id: str, account: str, _admin=Depends(require_admin)):
    bot = bots.get(bot_id)
    if bot is None:
        raise HTTPException(404, "بوت غير موجود")

    before = len(bot["licenses"])
    bot["licenses"] = [l for l in bot["licenses"] if l["account"] != account]
    if len(bot["licenses"]) == before:
        raise HTTPException(404, "الترخيص غير موجود")

    bot["cursors"].pop(account, None)
    persist_bots()
    log.info("[%s] حذف ترخيص %s", bot["chat_title"], account)
    return _bot_public(bot)


# ============================== نقطة اتصال الـEA ==============================

def _check_license(bot: dict, account: str):
    """
    يتحقق من الترخيص. يرجع (ok, reason).
    reason: "ACCOUNT" لو الحساب غير مرخّص، "EXPIRED" لو الاشتراك منتهي.
    """
    lic = next((l for l in bot.get("licenses", []) if l["account"] == account), None)
    if lic is None:
        return False, "ACCOUNT"

    try:
        exp = datetime.strptime(lic["expires"], "%Y-%m-%d").date()
    except (ValueError, KeyError):
        return False, "EXPIRED"

    if datetime.now(timezone.utc).date() > exp:
        return False, "EXPIRED"

    return True, ""


@app.get("/api/bots/{bot_id}/commands/next", response_class=PlainTextResponse)
async def next_command(bot_id: str, token: str = "", account: str = ""):
    bot = bots.get(bot_id)
    if bot is None:
        raise HTTPException(404, "بوت غير موجود")
    if not token or not secrets.compare_digest(token, bot["token"]):
        raise HTTPException(403, "توكن غير صحيح")

    account = (account or "").strip()
    now = time.time()

    if not account:
        bot.setdefault("denied", {})["(بدون رقم حساب)"] = {
            "reason": "ACCOUNT", "last": now,
            "count": bot.get("denied", {}).get("(بدون رقم حساب)", {}).get("count", 0) + 1,
        }
        return "DENIED|ACCOUNT|"

    # مهم: نسجّل محاولة الاتصال قبل فحص الترخيص، عشان نقدر نفرّق بين
    # "الروبوت ما وصل للسيرفر إطلاقاً" و "وصل بس انرفض" - الاثنين مشاكل مختلفة تماماً
    bot["last_seen"][account] = now

    # التحقق من الترخيص على السيرفر (لا يمكن تجاوزه بتعديل ملف الـEA)
    ok, reason = _check_license(bot, account)
    if not ok:
        prev = bot.setdefault("denied", {}).get(account, {})
        bot["denied"][account] = {
            "reason": reason, "last": now, "count": prev.get("count", 0) + 1,
        }
        if prev.get("count", 0) == 0:
            log.warning(
                "[%s] محاولة اتصال مرفوضة من الحساب %s (السبب: %s)",
                bot["chat_title"], account,
                "غير مرخّص" if reason == "ACCOUNT" else "اشتراك منتهي",
            )
        contact = load_config().get("telegram_link") or DEFAULT_TELEGRAM_LINK
        return f"DENIED|{reason}|{contact}"

    bot.get("denied", {}).pop(account, None)

    # كل حساب له مؤشر قراءة مستقل - عشان 10 حسابات يستلموا نفس الأمر
    # بدل ما أول واحد يسحبه ويحرم الباقي
    cursor = bot["cursors"].get(account)
    first_contact = cursor is None

    if first_contact:
        # أول اتصال لهاد الحساب بعد إقلاع السيرفر.
        # مهم: ما منبدأ من bot["seq"] (يعني "تجاهل كل اللي فات")، لأن هيك أي
        # روبوت يتصل بعد ما توصل الإشارة بثواني بيفوّتها كلياً. بدل هيك منبدأ
        # من أول أمر لسا موجود بالسجل وعمره ضمن نافذة قصيرة، فيلحق الإشارة.
        cutoff = now - FIRST_CONTACT_CATCHUP_SEC
        start = bot["seq"]
        for seq, _line, ts in bot["commands"]:
            if ts >= cutoff:
                start = seq - 1
                break
        bot["cursors"][account] = max(0, start)
        cursor = bot["cursors"][account]
        log.info(
            "[%s] اتصل حساب: %s (بيبدأ من الأمر رقم %d)",
            bot["chat_title"], account, cursor,
        )

    for seq, line, ts in bot["commands"]:
        if seq <= cursor:
            continue

        # حاجز الإشارات القديمة: أمر فتح مضى عليه أكثر من الحد ما ينفذ.
        # منقدّم المؤشر عشان ما نعلق عليه، ومنكمل للأمر اللي بعده.
        is_open = line.startswith("OPEN|") or line.startswith("REINFORCE|")
        if is_open and (now - ts) > MAX_OPEN_SIGNAL_AGE_SEC:
            bot["cursors"][account] = seq
            log.info(
                "[%s] تم تخطي أمر قديم (%ds) للحساب %s: %s",
                bot["chat_title"], int(now - ts), account, line,
            )
            continue

        bot["cursors"][account] = seq
        bot.setdefault("delivered", {})[account] = \
            bot.get("delivered", {}).get(account, 0) + 1
        return line

    return "NONE"


# ============================== الواجهة ==============================

class NoCacheStaticFiles(StaticFiles):
    """
    يمنع المتصفح من تخزين ملفات اللوحة. بدون هذا، بعد أي تحديث للسيرفر
    يظل المتصفح يستخدم نسخة JS قديمة فتظهر أخطاء غريبة (أزرار لا تستجيب).
    """

    async def get_response(self, path: str, scope):
        response = await super().get_response(path, scope)
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
        return response


app.mount("/static", NoCacheStaticFiles(directory=STATIC_DIR), name="static")


@app.get("/", response_class=HTMLResponse)
async def index():
    with open(os.path.join(STATIC_DIR, "index.html"), "r", encoding="utf-8") as f:
        html = f.read()
    return HTMLResponse(
        content=html,
        headers={
            "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
            "Pragma": "no-cache",
            "Expires": "0",
        },
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=PORT)
