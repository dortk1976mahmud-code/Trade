//+------------------------------------------------------------------+
//|                                              SmartTraderEA.mq5   |
//|                                    Smart EA - Automated Trading  |
//+------------------------------------------------------------------+
#property copyright "Smart EA"
#property version   "3.00"
#property strict

#include <Trade\Trade.mqh>
CTrade trade;

//====================================================================
//                         User Settings
//====================================================================
enum ENUM_SIZE_MODE
{
   MODE_FIXED = 0,   // Fixed number of trades
   MODE_AUTO  = 1    // Auto - by leverage and free margin
};

input ENUM_SIZE_MODE SizingMode = __SIZING_MODE__;       // How many trades to open
input int    TradesCount        = __TRADES_COUNT__;      // Number of trades  (Fixed mode)
input double MarginUsagePercent = __MARGIN_USAGE__;      // % of free margin  (Auto mode)
input int    MaxTradesPerSignal = __MAX_TRADES__;        // Max trades per signal (0 = no cap)
input double MinMarginLevel     = __MIN_MARGIN_LEVEL__;  // Stop opening below this margin level %

//====================================================================
//   Internal configuration (do not edit)
//====================================================================
const string ServerURL         = "__SERVER_URL__";
const string BotID             = "__BOT_ID__";
const string BotToken          = "__BOT_TOKEN__";
const double FixedLot          = __FIXED_LOT__;
const long   MagicNumber       = __MAGIC_NUMBER__;
const int    SlippagePoints    = __SLIPPAGE__;
const int    PollIntervalSec   = __POLL_INTERVAL__;
const double FallbackSLPercent = __FALLBACK_SL__;

const string AllowedAccount    = "__ALLOWED_ACCOUNT__";
const string ExpiryDate        = "__EXPIRY_DATE__";
const string ContactLink       = "__CONTACT_LINK__";

const int MAX_TRADES_PER_SIGNAL = 200;   // technical safety limit only
const int MAX_COMMANDS_PER_POLL = 20;

int      g_effectiveTradesCount = 1;
datetime g_lastWarnTime         = 0;
bool     g_licenseOK            = false;
string   g_blockReason          = "";
bool     g_serverDenied         = false;   // السيرفر رفض - ما نرجع نشتغل إلا لما يوافق هو

//--- Forward declarations
int  CalcTradesCount(string symbol, ENUM_POSITION_TYPE side, double lot, double price);
bool MarginLevelSafe();
string SymbolBase(string s);
string ResolveSymbol(string requested);
bool HttpGetCommand(string &responseOut);
void ExecuteCommandLine(string line);
void ProcessRemoteCommands();
void HandleServerDenial(string line);
void ShowActiveStatus();
void BlockEA(string status);
void DoOpen(string symbol, string sideStr, string slStr, string tpStr);
void DoReinforce(string symbol, string sideStr, string slStr, string tpStr);
void OpenPositions(string symbol, string sideStr, string slStr, string tpStr, bool isReinforce);
void DoClosePartial(string symbol, int count, bool oldestFirst);
void DoCloseAll();
void DoClose(string symbol);
void DoMoveSLEntry(string symbol);
void DoUpdateSL(string symbol, string slStr);
void DoUpdateTP(string symbol, string tpStr);

//+------------------------------------------------------------------+
//| Display current status on chart (kept minimal and generic)       |
//+------------------------------------------------------------------+
void ShowStatus(string status)
{
   string msg = "Smart EA\nStatus: " + status;
   if(status != "Active" && ContactLink != "")
      msg += "\nSubscribe: " + ContactLink;
   Comment(msg);
}

void ShowActiveStatus()
{
   string mode = (SizingMode == MODE_FIXED)
                 ? ("Fixed " + IntegerToString(g_effectiveTradesCount) + " trade(s)")
                 : "Auto (leverage based)";
   Comment("Smart EA\nStatus: Active\nExpires: " + ExpiryDate + "\nMode: " + mode);
}

//+------------------------------------------------------------------+
//| Block trading and show reason (no backend details ever printed) |
//+------------------------------------------------------------------+
void BlockEA(string status)
{
   g_licenseOK = false;
   g_blockReason = status;
   ShowStatus(status);
   Print("[Smart EA] Status: ", status);
}

//+------------------------------------------------------------------+
//| License check: account number + expiry date - both must be valid|
//+------------------------------------------------------------------+
bool CheckLicenseLocal()
{
   string currentAccount = IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN));
   if(currentAccount != AllowedAccount)
   {
      BlockEA("Not Active");
      return false;
   }

   datetime expiry = StringToTime(ExpiryDate + " 23:59:59");
   if(expiry == 0)
   {
      BlockEA("Not Active");
      return false;
   }
   if(TimeCurrent() > expiry)
   {
      // التاريخ المسجل بالملف انتهى - بس ممكن يكون المستخدم جدّد اشتراكه من
      // اللوحة. السيرفر هو المرجع النهائي، فنسأله قبل ما نوقف نهائياً.
      string probe;
      if(HttpGetCommand(probe))
      {
         StringTrimLeft(probe);
         StringTrimRight(probe);
         if(StringFind(probe, "DENIED|") != 0)
         {
            // السيرفر يقول الاشتراك ساري (تم التجديد) - نكمل شغل
            g_licenseOK = true;
            g_blockReason = "";
            g_serverDenied = false;
            Comment("Smart EA\nStatus: Active");
            Print("[Smart EA] Status: Active.");
            if(probe != "" && probe != "NONE")
               ExecuteCommandLine(probe);
            return true;
         }
      }
      BlockEA("Expired");
      return false;
   }

   g_licenseOK = true;
   g_blockReason = "";

   long daysLeft = (long)((expiry - TimeCurrent()) / 86400);
   if(daysLeft <= 7)
   {
      Comment("Smart EA\nStatus: Active\nExpires in ", daysLeft, " day(s) (", ExpiryDate, ")");
      Print("[Smart EA] Subscription expires in ", daysLeft, " day(s).");
   }
   else
   {
      ShowActiveStatus();
      Print("[Smart EA] Status: Active. Expires: ", ExpiryDate, ".");
   }
   return true;
}

//+------------------------------------------------------------------+
//| Handle a denial response (server is the final authority)         |
//+------------------------------------------------------------------+
void HandleServerDenial(string line)
{
   string parts[];
   int n = StringSplit(line, '|', parts);
   string reason = (n >= 2) ? parts[1] : "";
   string link   = (n >= 3 && parts[2] != "") ? parts[2] : ContactLink;

   string status = (reason == "EXPIRED") ? "Expired" : "Not Active";

   g_licenseOK = false;
   g_blockReason = status;
   g_serverDenied = true;

   string msg = "Smart EA\nStatus: " + status;
   if(link != "")
      msg += "\nSubscribe: " + link;

   Comment(msg);
   Print("[Smart EA] Status: ", status);
}

//+------------------------------------------------------------------+
int OnInit()
{
   // TradesCount = 0 means auto-sizing based on account capacity
   g_effectiveTradesCount = TradesCount;
   if(g_effectiveTradesCount < 1)
      g_effectiveTradesCount = 1;
   if(g_effectiveTradesCount > MAX_TRADES_PER_SIGNAL)
      g_effectiveTradesCount = MAX_TRADES_PER_SIGNAL;

   if(BotID == "" || BotToken == "" || ServerURL == "")
   {
      Print("[Smart EA] Configuration error. Please contact support.");
      return(INIT_PARAMETERS_INCORRECT);
   }

   // ===== License check first - before anything else =====
   if(!CheckLicenseLocal())
   {
      // Keep the EA attached (so the status message stays visible on the
      // chart) but re-check periodically in case the subscription is renewed.
      EventSetTimer(60);
      return(INIT_SUCCEEDED);
   }

   if(!MQLInfoInteger(MQL_TRADE_ALLOWED))
      Print("[Smart EA] Please enable Algo Trading.");

   trade.SetExpertMagicNumber(MagicNumber);
   trade.SetDeviationInPoints(SlippagePoints);
   trade.SetTypeFillingBySymbol(_Symbol);

   EventSetTimer(PollIntervalSec);

   Print("[Smart EA] Started. Status: Active. Expires: ", ExpiryDate, ".",
         SizingMode == MODE_FIXED
            ? (" Trades per signal: " + IntegerToString(g_effectiveTradesCount) + " (fixed)")
            : (MaxTradesPerSignal > 0
                 ? (" Trades per signal: auto, up to " + IntegerToString(MaxTradesPerSignal))
                 : " Trades per signal: auto (margin based)"));

   ProcessRemoteCommands();
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   EventKillTimer();
   Comment("");
}

//+------------------------------------------------------------------+
void OnTimer()
{
   if(!g_licenseOK)
   {
      // لو السيرفر هو اللي رفض، ما نرجع نشتغل بمجرد الفحص المحلي (لأنه رح
      // ينجح دايماً والملف فيه التاريخ القديم) - لازم نسأل السيرفر من جديد
      if(g_serverDenied)
      {
         string probe;
         if(!HttpGetCommand(probe))
            return;   // ما قدرنا نوصل السيرفر - نضل موقوفين ونحاول بعدين

         StringTrimLeft(probe);
         StringTrimRight(probe);

         if(StringFind(probe, "DENIED|") == 0)
         {
            HandleServerDenial(probe);   // لسا مرفوض
            return;
         }

         // السيرفر وافق - نرجع نشتغل
         g_serverDenied = false;
         g_licenseOK = true;
         ShowActiveStatus();
         Print("[Smart EA] Status: Active.");

         trade.SetExpertMagicNumber(MagicNumber);
         trade.SetDeviationInPoints(SlippagePoints);
         trade.SetTypeFillingBySymbol(_Symbol);
         EventSetTimer(PollIntervalSec);

         // لو الرد كان أمر فعلي (مو NONE) ننفذه بدل ما نضيعه
         if(probe != "" && probe != "NONE")
            ExecuteCommandLine(probe);
         return;
      }

      // رفض محلي (رقم حساب غلط أو تاريخ منتهي بالملف نفسه)
      if(CheckLicenseLocal())
      {
         Print("[Smart EA] Status: Active.");
         trade.SetExpertMagicNumber(MagicNumber);
         trade.SetDeviationInPoints(SlippagePoints);
         trade.SetTypeFillingBySymbol(_Symbol);
         EventSetTimer(PollIntervalSec);
      }
      return;
   }

   datetime expiry = StringToTime(ExpiryDate + " 23:59:59");
   if(expiry > 0 && TimeCurrent() > expiry)
   {
      BlockEA("Expired");
      EventSetTimer(60);
      return;
   }

   ProcessRemoteCommands();
}

//+------------------------------------------------------------------+
//| Poll for pending commands                                        |
//+------------------------------------------------------------------+
bool HttpGetCommand(string &responseOut)
{
   string account = IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN));
   string url = ServerURL + "/api/bots/" + BotID + "/commands/next"
              + "?token=" + BotToken + "&account=" + account;
   char   data[];
   char   result[];
   string result_headers;

   ResetLastError();
   int status = WebRequest("GET", url, "", 5000, data, result, result_headers);

   if(status == -1)
   {
      int err = GetLastError();
      if(TimeCurrent() - g_lastWarnTime > 60)
      {
         g_lastWarnTime = TimeCurrent();
         if(err == 4014 || err == 4060)
            Print("[Smart EA] Connection blocked. Please contact support.");
         else
            Print("[Smart EA] Connection issue. Retrying...");
      }
      return false;
   }

   if(status != 200)
   {
      if(TimeCurrent() - g_lastWarnTime > 60)
      {
         g_lastWarnTime = TimeCurrent();
         Print("[Smart EA] Connection issue. Please contact support.");
      }
      return false;
   }

   responseOut = CharArrayToString(result, 0, WHOLE_ARRAY, CP_UTF8);
   return true;
}

//+------------------------------------------------------------------+
void ProcessRemoteCommands()
{
   for(int i = 0; i < MAX_COMMANDS_PER_POLL; i++)
   {
      string response;
      if(!HttpGetCommand(response))
         return;

      StringTrimLeft(response);
      StringTrimRight(response);

      if(response == "" || response == "NONE")
         return;

      if(StringFind(response, "DENIED|") == 0)
      {
         HandleServerDenial(response);
         EventSetTimer(60);
         return;
      }

      ExecuteCommandLine(response);
   }
}

//+------------------------------------------------------------------+
//| Parse and execute a single command line                          |
//+------------------------------------------------------------------+
void ExecuteCommandLine(string line)
{
   if(!g_licenseOK)
      return;

   string parts[];
   int n = StringSplit(line, '|', parts);
   if(n == 0)
      return;

   string action = parts[0];

   if(action == "OPEN" && n >= 5)
      DoOpen(parts[1], parts[2], parts[3], parts[4]);
   else if(action == "REINFORCE" && n >= 5)
      DoReinforce(parts[1], parts[2], parts[3], parts[4]);
   else if(action == "CLOSE_ALL")
      DoCloseAll();
   else if(action == "CLOSE_FIRST" && n >= 3)
      DoClosePartial(parts[1], (int)StringToInteger(parts[2]), true);
   else if(action == "CLOSE_LAST" && n >= 3)
      DoClosePartial(parts[1], (int)StringToInteger(parts[2]), false);
   else if(action == "CLOSE" && n >= 2)
      DoClose(parts[1]);
   else if(action == "MOVE_SL_ENTRY" && n >= 2)
      DoMoveSLEntry(parts[1]);
   else if(action == "UPDATE_SL" && n >= 3)
      DoUpdateSL(parts[1], parts[2]);
   else if(action == "UPDATE_TP" && n >= 3)
      DoUpdateTP(parts[1], parts[2]);
}

//+------------------------------------------------------------------+
//| Map any broker symbol name to a canonical base                   |
//| GOLD / XAUUSD / XAUUSDm / XAUUSD.a  ->  "XAU"                    |
//+------------------------------------------------------------------+
string SymbolBase(string s)
{
   string u = s;
   StringToUpper(u);

   if(StringFind(u, "XAU")  >= 0 || StringFind(u, "GOLD")    >= 0) return "XAU";
   if(StringFind(u, "XAG")  >= 0 || StringFind(u, "SILVER")  >= 0) return "XAG";
   if(StringFind(u, "BTC")  >= 0 || StringFind(u, "BITCOIN") >= 0) return "BTC";
   if(StringFind(u, "ETH")  >= 0)                                  return "ETH";
   if(StringFind(u, "OIL")  >= 0 || StringFind(u, "WTI")     >= 0
      || StringFind(u, "BRENT") >= 0 || StringFind(u, "USOUSD") >= 0) return "OIL";

   // Forex and the rest: keep the leading letters only, so suffixes like
   // "m", ".a", "-ecn", "_raw" don't break the match (EURUSDm -> EURUSD)
   string letters = "";
   for(int i = 0; i < StringLen(u); i++)
   {
      ushort ch = StringGetCharacter(u, i);
      if(ch >= 'A' && ch <= 'Z')
         letters += ShortToString(ch);
      else
         break;
   }
   if(StringLen(letters) >= 6)
      return StringSubstr(letters, 0, 6);
   return (letters == "") ? u : letters;
}

//+------------------------------------------------------------------+
//| Resolve a signal symbol to the name this broker actually uses    |
//| Returns "" when this account has no matching instrument          |
//+------------------------------------------------------------------+
string ResolveSymbol(string requested)
{
   if(requested == "" || requested == "NA")
      return "";

   string wanted = SymbolBase(requested);

   // 1) The chart this EA is attached to - preferred when it matches,
   //    so the trader stays in control of which instrument is used
   if(SymbolBase(_Symbol) == wanted)
      return _Symbol;

   // 2) Exact name, if this broker happens to use it
   if(SymbolSelect(requested, true))
      return requested;

   // 3) Search every instrument this broker offers for an equivalent
   int total = SymbolsTotal(false);
   for(int i = 0; i < total; i++)
   {
      string name = SymbolName(i, false);
      if(SymbolBase(name) == wanted)
      {
         if(SymbolSelect(name, true))
            return name;
      }
   }

   // Nothing matched - safer to skip than to trade the wrong instrument
   Print("[Smart EA] Instrument not available on this account. Signal skipped.");
   return "";
}

//+------------------------------------------------------------------+
//| Is there already an open position with this symbol and side?     |
//+------------------------------------------------------------------+
bool HasPosition(string symbol, ENUM_POSITION_TYPE side)
{
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;
      if(PositionGetString(POSITION_SYMBOL) != symbol) continue;
      if((ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE) != side) continue;
      return true;
   }
   return false;
}

//+------------------------------------------------------------------+
double NormalizeLot(string symbol, double lot)
{
   double minLot  = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MIN);
   double maxLot  = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MAX);
   double lotStep = SymbolInfoDouble(symbol, SYMBOL_VOLUME_STEP);

   if(lotStep > 0)
      lot = MathFloor(lot / lotStep) * lotStep;
   if(minLot > 0 && lot < minLot) lot = minLot;
   if(maxLot > 0 && lot > maxLot) lot = maxLot;

   int lotDigits = 2;
   if(lotStep > 0)
      lotDigits = (int)MathMax(0, MathCeil(-MathLog10(lotStep)));

   return NormalizeDouble(lot, lotDigits);
}

//+------------------------------------------------------------------+
bool IsStopLevelValid(string symbol, ENUM_POSITION_TYPE side, double price, double sl, double tp)
{
   long   stopLevelPts = SymbolInfoInteger(symbol, SYMBOL_TRADE_STOPS_LEVEL);
   double point        = SymbolInfoDouble(symbol, SYMBOL_POINT);
   double minDistance  = stopLevelPts * point;

   if(minDistance <= 0)
      return true;

   if(sl > 0)
   {
      double d = (side == POSITION_TYPE_BUY) ? (price - sl) : (sl - price);
      if(d < minDistance) return false;
   }
   if(tp > 0)
   {
      double d = (side == POSITION_TYPE_BUY) ? (tp - price) : (price - tp);
      if(d < minDistance) return false;
   }
   return true;
}

//+------------------------------------------------------------------+
//| Decide how many trades to open for this signal                   |
//| Auto mode uses the margin one trade actually costs on this        |
//| account, which already reflects the account leverage.             |
//+------------------------------------------------------------------+
int CalcTradesCount(string symbol, ENUM_POSITION_TYPE side, double lot, double price)
{
   // 0 means no user cap - only margin decides. The constant below is just a
   // technical guard so a bad margin figure can never spin out of control.
   int hardCap = (MaxTradesPerSignal > 0) ? MaxTradesPerSignal : MAX_TRADES_PER_SIGNAL;
   if(hardCap > MAX_TRADES_PER_SIGNAL) hardCap = MAX_TRADES_PER_SIGNAL;

   // Fixed mode: the user decided the number
   if(SizingMode == MODE_FIXED)
      return MathMin(g_effectiveTradesCount, hardCap);

   // Auto mode: how much margin does a single trade cost here?
   ENUM_ORDER_TYPE ot = (side == POSITION_TYPE_BUY) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
   double marginOne = 0.0;
   if(!OrderCalcMargin(ot, symbol, lot, price, marginOne) || marginOne <= 0.0)
   {
      Print("[Smart EA] Could not calculate margin. Using 1 trade.");
      return 1;
   }

   double freeMargin = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
   double usage = MarginUsagePercent;
   if(usage <= 0.0)   usage = 10.0;
   if(usage > 100.0)  usage = 100.0;

   double budget = freeMargin * (usage / 100.0);
   int n = (int)MathFloor(budget / marginOne);

   if(n < 1) n = 1;
   if(n > hardCap) n = hardCap;

   Print("[Smart EA] Auto size: ", n, " trade(s)  |  Leverage 1:",
         AccountInfoInteger(ACCOUNT_LEVERAGE),
         "  |  Margin/trade ", DoubleToString(marginOne, 2),
         "  |  Free margin ", DoubleToString(freeMargin, 2));
   return n;
}

//+------------------------------------------------------------------+
//| Is it still safe to open one more trade?                         |
//+------------------------------------------------------------------+
bool MarginLevelSafe()
{
   if(MinMarginLevel <= 0.0)
      return true;
   // No open positions yet -> margin level is not meaningful
   if(AccountInfoDouble(ACCOUNT_MARGIN) <= 0.0)
      return true;
   double level = AccountInfoDouble(ACCOUNT_MARGIN_LEVEL);
   return (level >= MinMarginLevel);
}

//+------------------------------------------------------------------+
//| Open new trade(s), or update SL/TP if one is already open        |
//+------------------------------------------------------------------+
void DoOpen(string reqSymbol, string sideStr, string slStr, string tpStr)
{
   OpenPositions(reqSymbol, sideStr, slStr, tpStr, false);
}

//+------------------------------------------------------------------+
//| Reinforcement: add another position in the same direction even    |
//| when one is already open (channel asked to scale in)              |
//+------------------------------------------------------------------+
void DoReinforce(string reqSymbol, string sideStr, string slStr, string tpStr)
{
   Print("Reinforce");
   OpenPositions(reqSymbol, sideStr, slStr, tpStr, true);
}

//+------------------------------------------------------------------+
void OpenPositions(string reqSymbol, string sideStr, string slStr, string tpStr,
                   bool isReinforce)
{
   string symbol = ResolveSymbol(reqSymbol);
   if(symbol == "")
      return;

   ENUM_POSITION_TYPE side = (sideStr == "BUY") ? POSITION_TYPE_BUY : POSITION_TYPE_SELL;
   double sl = (slStr == "NA") ? 0.0 : StringToDouble(slStr);
   double tp = (tpStr == "NA") ? 0.0 : StringToDouble(tpStr);

   // Duplicate prevention - skipped for reinforcement, where adding a second
   // position in the same direction is exactly what was asked for
   if(!isReinforce && HasPosition(symbol, side))
   {
      if(sl > 0) DoUpdateSL(symbol, slStr);
      if(tp > 0) DoUpdateTP(symbol, tpStr);
      return;
   }

   double price = (side == POSITION_TYPE_BUY)
                  ? SymbolInfoDouble(symbol, SYMBOL_ASK)
                  : SymbolInfoDouble(symbol, SYMBOL_BID);
   if(price <= 0)
      return;

   int digits = (int)SymbolInfoInteger(symbol, SYMBOL_DIGITS);

   if(sl == 0.0 && FallbackSLPercent > 0.0)
   {
      double distance = price * (FallbackSLPercent / 100.0);
      sl = (side == POSITION_TYPE_BUY) ? price - distance : price + distance;
      sl = NormalizeDouble(sl, digits);
   }

   sl = (sl > 0) ? NormalizeDouble(sl, digits) : 0.0;
   tp = (tp > 0) ? NormalizeDouble(tp, digits) : 0.0;

   if(!IsStopLevelValid(symbol, side, price, sl, tp))
   {
      sl = 0.0;
      tp = 0.0;
   }

   double lot = NormalizeLot(symbol, FixedLot);
   if(lot <= 0)
      return;

   if(!isReinforce)
      Print(sideStr == "BUY" ? "Buy" : "Sell");

   int count = CalcTradesCount(symbol, side, lot, price);

   int opened = 0;
   for(int i = 0; i < count; i++)
   {
      // Safety: stop adding exposure if the account is getting stretched
      if(opened > 0 && !MarginLevelSafe())
      {
         Print("[Smart EA] Margin level limit reached. Opened ", opened, " of ", count, ".");
         break;
      }

      bool ok;
      if(side == POSITION_TYPE_BUY)
         ok = trade.Buy(lot, symbol, 0.0, sl, tp, "SmartEA");
      else
         ok = trade.Sell(lot, symbol, 0.0, sl, tp, "SmartEA");

      if(ok)
      {
         opened++;
      }
      else
      {
         uint rc = trade.ResultRetcode();
         if(rc == TRADE_RETCODE_NO_MONEY || rc == TRADE_RETCODE_MARKET_CLOSED ||
            rc == TRADE_RETCODE_TRADE_DISABLED || rc == TRADE_RETCODE_INVALID_VOLUME)
            break;
      }
   }

   if(opened == 0)
      Print("[Smart EA] Order failed.");
}

//+------------------------------------------------------------------+
void DoCloseAll()
{
   int closed = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;
      if(trade.PositionClose(ticket))
         closed++;
   }
   if(closed > 0)
      Print("Close");
}

//+------------------------------------------------------------------+
void DoClose(string reqSymbol)
{
   if(reqSymbol == "NA" || reqSymbol == "")
   {
      DoCloseAll();
      return;
   }
   string wanted = SymbolBase(reqSymbol);
   int closed = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;
      if(SymbolBase(PositionGetString(POSITION_SYMBOL)) != wanted) continue;
      if(trade.PositionClose(ticket))
         closed++;
   }
   if(closed > 0)
      Print("Close");
}

//+------------------------------------------------------------------+
//| Close only the oldest (or newest) N positions, leaving the rest   |
//| open. Used when the channel says "close the first trade and keep  |
//| the reinforcement one".                                           |
//+------------------------------------------------------------------+
void DoClosePartial(string reqSymbol, int count, bool oldestFirst)
{
   if(count < 1) count = 1;

   bool anySymbol = (reqSymbol == "NA" || reqSymbol == "");
   string wanted = anySymbol ? "" : SymbolBase(reqSymbol);

   ulong    tickets[];
   datetime times[];
   int found = 0;

   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;
      if(!anySymbol && SymbolBase(PositionGetString(POSITION_SYMBOL)) != wanted) continue;

      ArrayResize(tickets, found + 1);
      ArrayResize(times,   found + 1);
      tickets[found] = ticket;
      times[found]   = (datetime)PositionGetInteger(POSITION_TIME);
      found++;
   }

   if(found == 0)
      return;

   // Simple insertion sort by open time (position counts are small)
   for(int i = 1; i < found; i++)
   {
      ulong    kt = tickets[i];
      datetime kv = times[i];
      int j = i - 1;
      while(j >= 0 && ((oldestFirst && times[j] > kv) || (!oldestFirst && times[j] < kv)))
      {
         tickets[j + 1] = tickets[j];
         times[j + 1]   = times[j];
         j--;
      }
      tickets[j + 1] = kt;
      times[j + 1]   = kv;
   }

   int toClose = MathMin(count, found);
   int closed = 0;
   for(int i = 0; i < toClose; i++)
   {
      if(trade.PositionClose(tickets[i]))
         closed++;
   }

   if(closed > 0)
      Print("Close ", closed, " of ", found);
}

//+------------------------------------------------------------------+
void DoMoveSLEntry(string reqSymbol)
{
   bool anySymbol = (reqSymbol == "NA" || reqSymbol == "");
   string wanted = anySymbol ? "" : SymbolBase(reqSymbol);
   int moved = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;
      if(!anySymbol && SymbolBase(PositionGetString(POSITION_SYMBOL)) != wanted) continue;

      double entry = PositionGetDouble(POSITION_PRICE_OPEN);
      double tp    = PositionGetDouble(POSITION_TP);
      if(trade.PositionModify(ticket, entry, tp))
         moved++;
   }
}

//+------------------------------------------------------------------+
void DoUpdateSL(string reqSymbol, string slStr)
{
   double slRaw = StringToDouble(slStr);
   if(slRaw <= 0) return;

   bool anySymbol = (reqSymbol == "NA" || reqSymbol == "");
   string wanted = anySymbol ? "" : SymbolBase(reqSymbol);

   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;
      string posSymbol = PositionGetString(POSITION_SYMBOL);
      if(!anySymbol && SymbolBase(posSymbol) != wanted) continue;

      int    digits = (int)SymbolInfoInteger(posSymbol, SYMBOL_DIGITS);
      double sl     = NormalizeDouble(slRaw, digits);
      double tp     = PositionGetDouble(POSITION_TP);
      trade.PositionModify(ticket, sl, tp);
   }
}

//+------------------------------------------------------------------+
void DoUpdateTP(string reqSymbol, string tpStr)
{
   double tpRaw = StringToDouble(tpStr);
   if(tpRaw <= 0) return;

   bool anySymbol = (reqSymbol == "NA" || reqSymbol == "");
   string wanted = anySymbol ? "" : SymbolBase(reqSymbol);

   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;
      string posSymbol = PositionGetString(POSITION_SYMBOL);
      if(!anySymbol && SymbolBase(posSymbol) != wanted) continue;

      int    digits = (int)SymbolInfoInteger(posSymbol, SYMBOL_DIGITS);
      double tp     = NormalizeDouble(tpRaw, digits);
      double sl     = PositionGetDouble(POSITION_SL);
      trade.PositionModify(ticket, sl, tp);
   }
}
//+------------------------------------------------------------------+
