const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

const S = {
  lock: $("#section-lock"),
  config: $("#section-config"),
  login: $("#section-login"),
  addBot: $("#section-add-bot"),
  bots: $("#section-bots"),
};

let allDialogs = [];
let logTimers = {};
let pendingDialog = null; // القناة اللي بننتظر إعداداتها
let editingBotId = null;

// ============================== أدوات مساعدة ==============================

function toast(msg, ok = false) {
  const t = $("#toast");
  t.textContent = msg;
  t.className = "toast" + (ok ? " success" : "");
  if (!ok) console.error("[Smart EA]", msg);
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(() => t.classList.add("hidden"), 6000);
}

// أي خطأ JS غير متوقع يظهر للمستخدم بدل ما يوقف كل شي بصمت
window.addEventListener("error", (e) => {
  const t = $("#toast");
  if (t) {
    t.textContent = "خطأ بالصفحة: " + e.message + " — جرّب Ctrl+Shift+R";
    t.className = "toast";
  }
});

async function api(url, options) {
  const res = await fetch(url, options);
  const raw = await res.text();
  let data = null;
  try { data = raw ? JSON.parse(raw) : null; } catch { data = raw; }
  if (!res.ok) {
    // انتهت الجلسة -> رجّع لشاشة القفل
    if (res.status === 401 && !url.includes("/api/auth/")) {
      Object.values(logTimers).forEach(clearInterval);
      logTimers = {};
      show(S.lock);
      const p = $("#admin-password");
      if (p) p.focus();
      throw new Error("لازم تسجل دخول للوحة أولاً (كلمة مرور ADMIN_PASSWORD)");
    }
    const msg = (data && data.detail) ? data.detail : (raw || res.statusText);
    throw new Error(msg);
  }
  return data;
}

function esc(str) {
  const d = document.createElement("div");
  d.textContent = str ?? "";
  return d.innerHTML;
}

function show(section) {
  Object.values(S).forEach((s) => s.classList.add("hidden"));
  if (Array.isArray(section)) section.forEach((s) => s.classList.remove("hidden"));
  else section.classList.remove("hidden");
}

// ============================== التهيئة ==============================

async function init() {
  try {
    // أول شي: هل اللوحة محمية بكلمة مرور؟
    const auth = await api("/api/auth/status");
    if (auth.protected && !auth.authenticated) {
      show(S.lock);
      $("#admin-password").focus();
      return;
    }
    await afterAuth();
  } catch (e) {
    toast("خطأ بالتحميل: " + e.message);
  }
}

async function afterAuth() {
  try {
    const cfg = await api("/api/config");
    if (!cfg.configured) return show(S.config);

    const status = await api("/api/telegram/status");
    if (status.error) toast(status.error);
    if (status.needs_password) {
      show(S.login);
      switchTab("phone");
      $("#step-phone").classList.add("hidden");
      $("#step-code").classList.add("hidden");
      $("#step-password").classList.remove("hidden");
      return;
    }
    if (!status.logged_in) return show(S.login);

    await showMain();
  } catch (e) {
    toast("خطأ بالتحميل: " + e.message);
    show(S.config);
  }
}

// ============================== دخول اللوحة ==============================

$("#btn-admin-login").addEventListener("click", async () => {
  const password = $("#admin-password").value;
  if (!password) return toast("اكتب كلمة المرور");

  const btn = $("#btn-admin-login");
  btn.disabled = true;
  btn.textContent = "جاري التحقق...";
  try {
    await api("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password }),
    });
    $("#admin-password").value = "";
    await afterAuth();
  } catch (err) {
    toast(err.message);
  } finally {
    btn.disabled = false;
    btn.textContent = "دخول";
  }
});

$("#admin-password").addEventListener("keydown", (e) => {
  if (e.key === "Enter") { e.preventDefault(); $("#btn-admin-login").click(); }
});

async function showMain() {
  show([S.addBot, S.bots]);
  try {
    const cfg = await api("/api/config");
    $("#telegram-link").value = cfg.telegram_link || "";
  } catch { /* غير حرج */ }
  await Promise.all([loadDialogs(), refreshBots()]);
}

// ============================== الإعداد الأولي ==============================

$("#config-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const body = {
    api_id: parseInt($("#cfg-api-id").value, 10),
    api_hash: $("#cfg-api-hash").value.trim(),
    deepseek_api_key: $("#cfg-deepseek-key").value.trim(),
  };
  const btn = e.target.querySelector("button");
  btn.disabled = true;
  try {
    await api("/api/config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    show(S.login);
  } catch (err) {
    toast(err.message);
  } finally {
    btn.disabled = false;
  }
});

// ============================== التبويبات ==============================

function switchTab(name) {
  $$(".tab").forEach((t) => t.classList.toggle("active", t.dataset.tab === name));
  $("#tab-phone").classList.toggle("hidden", name !== "phone");
  $("#tab-qr").classList.toggle("hidden", name !== "qr");
}

$$(".tab").forEach((t) => t.addEventListener("click", () => switchTab(t.dataset.tab)));

// ============================== تسجيل الدخول بالرقم ==============================

$("#btn-send-code").addEventListener("click", async () => {
  const phone = $("#login-phone").value.trim();
  if (!phone) return toast("اكتب رقم هاتفك أولاً");

  const btn = $("#btn-send-code");
  btn.disabled = true;
  btn.textContent = "جاري الإرسال...";
  try {
    const res = await api("/api/telegram/phone/send_code", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ phone }),
    });
    if (res.already_logged_in) return showMain();
    $("#step-phone").classList.add("hidden");
    $("#step-code").classList.remove("hidden");
    $("#login-code").focus();
    toast("تم إرسال الكود، شيك على تيليجرام", true);
  } catch (err) {
    toast(err.message);
  } finally {
    btn.disabled = false;
    btn.textContent = "إرسال كود التحقق";
  }
});

$("#btn-back-phone").addEventListener("click", () => {
  $("#step-code").classList.add("hidden");
  $("#step-phone").classList.remove("hidden");
});

$("#btn-verify-code").addEventListener("click", async () => {
  const code = $("#login-code").value.trim();
  if (!code) return toast("اكتب الكود");

  const btn = $("#btn-verify-code");
  btn.disabled = true;
  btn.textContent = "جاري التحقق...";
  try {
    const res = await api("/api/telegram/phone/verify_code", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code }),
    });
    if (res.needs_password) {
      $("#step-code").classList.add("hidden");
      $("#step-password").classList.remove("hidden");
      $("#login-password").focus();
      toast("حسابك محمي بتحقق ثنائي - اكتب كلمة المرور", true);
      return;
    }
    toast("تم تسجيل الدخول!", true);
    await showMain();
  } catch (err) {
    toast(err.message);
  } finally {
    btn.disabled = false;
    btn.textContent = "تأكيد";
  }
});

$("#btn-verify-password").addEventListener("click", async () => {
  const password = $("#login-password").value;
  if (!password) return toast("اكتب كلمة المرور");

  const btn = $("#btn-verify-password");
  btn.disabled = true;
  btn.textContent = "جاري التحقق...";
  try {
    await api("/api/telegram/phone/verify_password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password }),
    });
    toast("تم تسجيل الدخول!", true);
    await showMain();
  } catch (err) {
    toast(err.message);
  } finally {
    btn.disabled = false;
    btn.textContent = "تأكيد";
  }
});

// إدخال بزر Enter
["login-phone", "login-code", "login-password"].forEach((id) => {
  $("#" + id).addEventListener("keydown", (e) => {
    if (e.key !== "Enter") return;
    e.preventDefault();
    if (id === "login-phone") $("#btn-send-code").click();
    if (id === "login-code") $("#btn-verify-code").click();
    if (id === "login-password") $("#btn-verify-password").click();
  });
});

// ============================== تسجيل الدخول بالباركود ==============================

$("#btn-generate-qr").addEventListener("click", async () => {
  const btn = $("#btn-generate-qr");
  btn.disabled = true;
  try {
    const res = await api("/api/telegram/qr", { method: "POST" });
    if (res.already_logged_in) return showMain();
    $("#qr-not-started").classList.add("hidden");
    $("#qr-box").classList.remove("hidden");
    $("#qr-image").src = "data:image/png;base64," + res.qr_image_base64;
    pollQrLogin();
  } catch (err) {
    toast(err.message);
    btn.disabled = false;
  }
});

async function pollQrLogin() {
  try {
    const st = await api("/api/telegram/status");
    if (st.needs_password) {
      switchTab("phone");
      $("#step-phone").classList.add("hidden");
      $("#step-code").classList.add("hidden");
      $("#step-password").classList.remove("hidden");
      toast("حسابك محمي بتحقق ثنائي - اكتب كلمة المرور", true);
      return;
    }
    if (st.logged_in) {
      toast("تم تسجيل الدخول!", true);
      return showMain();
    }
  } catch (e) { /* نكمل المحاولة */ }
  setTimeout(pollQrLogin, 2500);
}

// ============================== تسجيل الخروج ==============================

$("#btn-logout").addEventListener("click", async () => {
  if (!confirm("متأكد بدك تسجل خروج؟ رح تنحذف كل البوتات.")) return;
  try {
    await api("/api/telegram/logout", { method: "POST" });
    Object.values(logTimers).forEach(clearInterval);
    logTimers = {};
    location.reload();
  } catch (err) {
    toast(err.message);
  }
});

// ============================== القنوات ==============================

async function loadDialogs() {
  try {
    allDialogs = await api("/api/telegram/dialogs");
    renderDialogs(allDialogs);
  } catch (err) {
    toast("تعذر جلب القنوات: " + err.message);
  }
}

$("#btn-refresh-dialogs").addEventListener("click", loadDialogs);

$("#dialog-search").addEventListener("input", (e) => {
  const q = e.target.value.trim().toLowerCase();
  renderDialogs(
    allDialogs.filter(
      (d) => d.name.toLowerCase().includes(q) || (d.username || "").toLowerCase().includes(q)
    )
  );
});

function renderDialogs(list) {
  const c = $("#dialogs-list");
  if (!list.length) {
    c.innerHTML = `<div class="empty-state">ما فيه نتائج</div>`;
    return;
  }
  c.innerHTML = list
    .slice(0, 60)
    .map(
      (d) => `
      <div class="dialog-item">
        <div>
          <span class="name">${esc(d.name)}</span>
          ${d.username ? `<span class="username">${esc(d.username)}</span>` : ""}
        </div>
        <button class="secondary" data-id="${esc(d.id)}" data-name="${esc(d.name)}">
          ابدأ المراقبة
        </button>
      </div>`
    )
    .join("");

  c.querySelectorAll("button[data-id]").forEach((btn) => {
    btn.addEventListener("click", () => {
      pendingDialog = { id: btn.dataset.id, name: btn.dataset.name };
      editingBotId = null;
      openModal("إعدادات: " + btn.dataset.name,
        { trades: 0, lot: 0.01, sl: 0.5, margin: 20, maxTrades: 0, minMargin: 300 });
    });
  });
}

// ============================== النافذة المنبثقة ==============================

function openModal(title, v) {
  $("#modal-title").textContent = title;
  $("#modal-trades").value = v.trades;
  $("#modal-lot").value = v.lot;
  $("#modal-sl").value = v.sl;
  $("#modal-margin").value = v.margin ?? 20;
  $("#modal-maxtrades").value = v.maxTrades ?? 0;
  $("#modal-minmargin").value = v.minMargin ?? 300;
  updateModalTotal();
  $("#modal-overlay").classList.remove("hidden");
}

function closeModal() {
  $("#modal-overlay").classList.add("hidden");
  pendingDialog = null;
  editingBotId = null;
}

function updateModalTotal() {
  const t = parseInt($("#modal-trades").value, 10) || 0;
  const l = parseFloat($("#modal-lot").value) || 0;
  const auto = t === 0;

  $("#auto-fields").classList.toggle("hidden", !auto);

  if (auto) {
    const mx = parseInt($("#modal-maxtrades").value, 10) || 0;
    const mg = parseFloat($("#modal-margin").value) || 0;
    $("#modal-total").innerHTML = mx > 0
      ? `الوضع <b>تلقائي</b>: يفتح حسب الرافعة والهامش، بحد أقصى <b>${mx}</b> صفقة = <b>${(mx * l).toFixed(2)}</b> لوت`
      : `الوضع <b>تلقائي بدون حد</b>: يفتح حسب الرافعة والهامش الحر (${mg}%) — العدد يتغير حسب كل حساب`;
  } else {
    $("#modal-total").innerHTML =
      `الوضع <b>يدوي</b>: ${t} صفقة × ${l} = <b>${(t * l).toFixed(2)}</b> لوت لكل إشارة`;
  }
}

["modal-trades", "modal-lot", "modal-maxtrades", "modal-margin"].forEach((id) =>
  $("#" + id).addEventListener("input", updateModalTotal)
);
$("#modal-cancel").addEventListener("click", closeModal);
$("#modal-overlay").addEventListener("click", (e) => {
  if (e.target.id === "modal-overlay") closeModal();
});

$("#modal-confirm").addEventListener("click", async () => {
  const payload = {
    lot: parseFloat($("#modal-lot").value),
    trades_count: parseInt($("#modal-trades").value, 10),
    fallback_sl: parseFloat($("#modal-sl").value),
    margin_usage: parseFloat($("#modal-margin").value),
    max_trades: parseInt($("#modal-maxtrades").value, 10),
    min_margin_level: parseFloat($("#modal-minmargin").value),
  };
  if (!(payload.lot > 0)) return toast("حجم اللوت لازم يكون أكبر من صفر");
  if (!(payload.trades_count >= 0)) return toast("عدد الصفقات لازم يكون 0 أو أكثر");
  if (!(payload.margin_usage > 0 && payload.margin_usage <= 100))
    return toast("نسبة الهامش لازم تكون بين 1 و 100");
  if (!(payload.max_trades >= 0)) return toast("الحد الأقصى لازم يكون 0 أو أكثر");

  const btn = $("#modal-confirm");
  btn.disabled = true;
  try {
    if (editingBotId) {
      await api(`/api/bots/${editingBotId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      toast("تم حفظ الإعدادات - نزّل ملف EA جديد عشان تطبق التغييرات", true);
    } else {
      await api("/api/bots", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: pendingDialog.id,
          chat_title: pendingDialog.name,
          ...payload,
        }),
      });
      toast("تمت إضافة البوت - نزّل ملف الـEA من بطاقته", true);
    }
    closeModal();
    await refreshBots();
  } catch (err) {
    toast(err.message);
  } finally {
    btn.disabled = false;
  }
});

// ============================== البوتات ==============================

async function refreshBots() {
  let list;
  try {
    list = await api("/api/bots");
  } catch (err) {
    return toast(err.message);
  }

  const c = $("#bots-list");
  if (!list.length) {
    c.innerHTML = `<div class="empty-state">ما فيه بوتات بعد — اختار قناة من فوق</div>`;
    return;
  }

  // تنبيه بارز فوق القائمة لأي ترخيص منتهي أو قرب ينتهي
  const expired = [];
  const soon = [];
  list.forEach((b) => b.licenses.forEach((l) => {
    if (l.status === "منتهي") expired.push(`${l.account} (${l.note || "بدون اسم"})`);
    else if (l.status === "قرب ينتهي") soon.push(`${l.account} — باقي ${l.days_left} يوم`);
  }));

  let banner = "";

  // ملخص الاتصال - أهم رقم: كم روبوت واصل فعلاً من أصل المرخّصين
  let totalLic = 0, totalOnline = 0, neverSeen = [];
  list.forEach((b) => b.licenses.forEach((l) => {
    totalLic++;
    if (l.online) totalOnline++;
    else if (l.last_seen_ago == null && l.status !== "منتهي") neverSeen.push(l.account);
  }));
  if (totalLic > 0) {
    const cls2 = totalOnline === totalLic ? "alert-ok"
               : (totalOnline === 0 ? "alert-bad" : "alert-warn");
    banner += `<div class="alert ${cls2}">
      📡 <b>${totalOnline} من ${totalLic} روبوت متصل الآن</b>
      ${neverSeen.length ? `<div class="alert-hint">
        ${neverSeen.length} حساب ما وصل للسيرفر ولا مرة: <span dir="ltr">${neverSeen.map(esc).join("، ")}</span><br>
        على أجهزتهم تحقق من: MT5 شغالة؟ زر Algo Trading أخضر؟ الرابط مضاف بـ Tools → Options → Expert Advisors → Allow WebRequest؟
      </div>` : ""}
    </div>`;
  }

  if (expired.length) {
    banner += `<div class="alert alert-bad">
      ⛔ <b>${expired.length} ترخيص منتهي — الروبوتات عندهم متوقفة الآن:</b><br>
      ${expired.map(esc).join("<br>")}
      <div class="alert-hint">اضغط "تعديل" جنب كل حساب ومدّد التاريخ — رح يشتغلوا خلال دقيقة تلقائياً.</div>
    </div>`;
  }
  if (soon.length) {
    banner += `<div class="alert alert-warn">
      ⚠️ <b>${soon.length} ترخيص قرب ينتهي:</b><br>${soon.map(esc).join("<br>")}
    </div>`;
  }

  c.innerHTML = banner + list.map((b) => `
    <div class="bot-card">
      <div class="bot-title">
        <span>${esc(b.chat_title)}</span>
        <span class="badge">${b.licenses.length} ترخيص</span>
      </div>

      <div class="bot-stats">
        ${b.trades_count === 0
          ? `<span>الوضع: <b class="auto-tag">تلقائي حسب الرافعة</b></span>
             <span>هامش: <b>${b.margin_usage}%</b></span>
             <span>حد أقصى: <b>${b.max_trades > 0 ? b.max_trades + " صفقة" : "بدون حد"}</b></span>
             <span>أدنى هامش: <b>${b.min_margin_level}%</b></span>`
          : `<span>عدد الصفقات: <b>${b.trades_count}</b></span>
             <span>الإجمالي: <b>${(b.trades_count * b.lot).toFixed(2)}</b> لوت</span>`}
        <span>اللوت: <b>${b.lot}</b></span>
        <span>وقف احتياطي: <b>${b.fallback_sl}%</b></span>
      </div>

      <div class="bot-actions">
        <button data-act="addlic" data-id="${b.id}">+ إضافة حساب</button>
        <button data-act="edit" data-id="${b.id}" class="secondary">إعدادات التداول</button>
        <button data-act="delete" data-id="${b.id}" class="danger">حذف البوت</button>
      </div>

      ${renderLicenses(b)}

      <table class="log-table">
        <thead><tr><th>الوقت</th><th>الرسالة</th><th>الأمر</th></tr></thead>
        <tbody id="log-${b.id}">
          <tr><td colspan="3" class="empty-state">لا يوجد سجل بعد</td></tr>
        </tbody>
      </table>
    </div>`).join("");

  c.querySelectorAll("button[data-act]").forEach((btn) => {
    const id = btn.dataset.id;
    const bot = list.find((x) => x.id === id);
    const acc = btn.dataset.account;
    btn.addEventListener("click", () => {
      const act = btn.dataset.act;
      if (act === "edit") {
        editingBotId = id; pendingDialog = null;
        openModal("إعدادات: " + bot.chat_title, {
          trades: bot.trades_count, lot: bot.lot, sl: bot.fallback_sl,
          margin: bot.margin_usage, maxTrades: bot.max_trades,
          minMargin: bot.min_margin_level,
        });
      }
      if (act === "delete") deleteBot(id);
      if (act === "addlic") openLicenseModal(id, null);
      if (act === "editlic") {
        const lic = bot.licenses.find((l) => l.account === acc);
        openLicenseModal(id, lic);
      }
      if (act === "dellic") deleteLicense(id, acc);
      if (act === "download") downloadEA(id, acc);
    });
  });

  list.forEach((b) => startLogPolling(b.id));

  // تحديث دوري لحالة الاتصال والتراخيص (كل 15 ثانية)
  if (!window._botsTimer) {
    window._botsTimer = setInterval(() => {
      if (!S.bots.classList.contains("hidden")) refreshBots();
    }, 15000);
  }
}

function fmtAgo(sec) {
  if (sec < 60) return `${sec} ثانية`;
  if (sec < 3600) return `${Math.floor(sec / 60)} دقيقة`;
  if (sec < 86400) return `${Math.floor(sec / 3600)} ساعة`;
  return `${Math.floor(sec / 86400)} يوم`;
}

function renderLicenses(b) {
  if (!b.licenses.length) {
    return `<div class="lic-empty">ما فيه حسابات مرخّصة — اضغط "إضافة حساب" عشان تسمح لحساب MT5 يستخدم هاد البوت</div>`;
  }
  const rows = b.licenses.map((l) => {
    let cls = "ok";
    if (l.status === "منتهي") cls = "bad";
    else if (l.status === "قرب ينتهي") cls = "warn";

    const dot = l.online
      ? `<span class="dot on" title="متصل الآن"></span>`
      : `<span class="dot off" title="${l.last_seen_ago == null
            ? "ما وصل للسيرفر ولا مرة"
            : "آخر اتصال قبل " + fmtAgo(l.last_seen_ago)}"></span>`;

    const conn = l.online
      ? `<span class="sub ok-txt">متصل</span>`
      : (l.last_seen_ago == null
          ? `<span class="sub bad-txt">ما وصل أبداً</span>`
          : `<span class="sub warn-txt">مفصول من ${fmtAgo(l.last_seen_ago)}</span>`);

    let expText = esc(l.expires);
    if (l.days_left != null) {
      expText += l.days_left < 0
        ? ` <span class="sub bad-txt">(انتهى من ${Math.abs(l.days_left)} يوم)</span>`
        : ` <span class="sub">(باقي ${l.days_left} يوم)</span>`;
    }

    return `
      <tr>
        <td>${dot} <span dir="ltr">${esc(l.account)}</span><br>${conn}</td>
        <td>${esc(l.note || "—")}</td>
        <td dir="ltr">${expText}</td>
        <td><span class="pill ${cls}">${esc(l.status)}</span></td>
        <td><span class="sub">${l.delivered} أمر</span></td>
        <td class="lic-btns">
          <button data-act="download" data-id="${b.id}" data-account="${esc(l.account)}">EA</button>
          <button data-act="editlic" data-id="${b.id}" data-account="${esc(l.account)}" class="secondary">تعديل</button>
          <button data-act="dellic" data-id="${b.id}" data-account="${esc(l.account)}" class="danger">حذف</button>
        </td>
      </tr>`;
  }).join("");

  const unknownBox = (b.unknown_attempts && b.unknown_attempts.length)
    ? `<div class="alert alert-warn" style="margin-top:12px">
         ⚠️ <b>حسابات حاولت الاتصال وهي غير مرخّصة:</b><br>
         ${b.unknown_attempts.map((u) =>
            `<span dir="ltr">${esc(u.account)}</span> — ${u.count} محاولة، آخرها قبل ${fmtAgo(u.ago)}`
          ).join("<br>")}
         <div class="alert-hint">غالباً ملف EA انثبت على حساب غير اللي اتولّد له. أضف الحساب للتراخيص، أو نزّل ملف EA صحيح لهاد الحساب.</div>
       </div>`
    : "";

  return `
    <table class="lic-table">
      <thead><tr><th>رقم الحساب</th><th>ملاحظة</th><th>ينتهي</th><th>الحالة</th><th>استلم</th><th></th></tr></thead>
      <tbody>${rows}</tbody>
    </table>${unknownBox}`;
}

// ============================== التراخيص ==============================

let licBotId = null;
let licEditAccount = null;

function openLicenseModal(botId, lic) {
  licBotId = botId;
  licEditAccount = lic ? lic.account : null;

  $("#lic-title").textContent = lic ? "تعديل ترخيص" : "إضافة حساب مرخّص";
  $("#lic-account").value = lic ? lic.account : "";
  $("#lic-account").disabled = !!lic;
  $("#lic-note").value = lic ? (lic.note || "") : "";

  if (lic) {
    $("#lic-expires").value = lic.expires;
  } else {
    const d = new Date();
    d.setMonth(d.getMonth() + 1);
    $("#lic-expires").value = d.toISOString().slice(0, 10);
  }
  $("#lic-overlay").classList.remove("hidden");
}

function closeLicenseModal() {
  $("#lic-overlay").classList.add("hidden");
  licBotId = null;
  licEditAccount = null;
}

$("#lic-cancel").addEventListener("click", closeLicenseModal);
$("#lic-overlay").addEventListener("click", (e) => {
  if (e.target.id === "lic-overlay") closeLicenseModal();
});

$("#lic-confirm").addEventListener("click", async () => {
  const account = $("#lic-account").value.trim();
  const expires = $("#lic-expires").value;
  const note = $("#lic-note").value.trim();

  if (!account) return toast("اكتب رقم الحساب");
  if (!/^\d+$/.test(account)) return toast("رقم الحساب لازم يكون أرقام فقط");
  if (!expires) return toast("حدد تاريخ الانتهاء");

  const btn = $("#lic-confirm");
  btn.disabled = true;
  try {
    if (licEditAccount) {
      await api(`/api/bots/${licBotId}/licenses/${licEditAccount}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ expires, note }),
      });
      toast("تم تحديث الترخيص", true);
    } else {
      await api(`/api/bots/${licBotId}/licenses`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ account, expires, note }),
      });
      toast("تمت إضافة الحساب — نزّل ملف الـEA من زر EA", true);
    }
    closeLicenseModal();
    await refreshBots();
  } catch (err) {
    toast(err.message);
  } finally {
    btn.disabled = false;
  }
});

async function deleteLicense(botId, account) {
  if (!confirm(`متأكد بدك تلغي ترخيص الحساب ${account}؟\nالـEA عنده رح يوقف فوراً.`)) return;
  try {
    await api(`/api/bots/${botId}/licenses/${account}`, { method: "DELETE" });
    toast("تم إلغاء الترخيص", true);
    await refreshBots();
  } catch (err) {
    toast(err.message);
  }
}

// ============================== رابط التواصل ==============================

$("#btn-save-link").addEventListener("click", async () => {
  const btn = $("#btn-save-link");
  btn.disabled = true;
  try {
    await api("/api/config/telegram_link", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ telegram_link: $("#telegram-link").value.trim() }),
    });
    toast("تم حفظ رابط التواصل — نزّل ملفات EA جديدة عشان يظهر فيها", true);
  } catch (err) {
    toast(err.message);
  } finally {
    btn.disabled = false;
  }
});

function downloadEA(botId, account) {
  const url = `/api/bots/${botId}/ea`
    + `?server_url=${encodeURIComponent(window.location.origin)}`
    + `&account=${encodeURIComponent(account)}`;
  const a = document.createElement("a");
  a.href = url;
  a.download = "";
  document.body.appendChild(a);
  a.click();
  a.remove();
}

async function deleteBot(botId) {
  if (!confirm("متأكد بدك تحذف مراقبة هاي القناة؟")) return;
  try {
    await api(`/api/bots/${botId}`, { method: "DELETE" });
    clearInterval(logTimers[botId]);
    delete logTimers[botId];
    await refreshBots();
  } catch (err) {
    toast(err.message);
  }
}

function startLogPolling(botId) {
  if (logTimers[botId]) return;
  const update = async () => {
    const tbody = $("#log-" + botId);
    if (!tbody) {
      clearInterval(logTimers[botId]);
      delete logTimers[botId];
      return;
    }
    try {
      const logs = await api(`/api/bots/${botId}/log`);
      if (!logs.length) {
        tbody.innerHTML = `<tr><td colspan="3" class="empty-state">لا يوجد سجل بعد</td></tr>`;
        return;
      }
      tbody.innerHTML = logs
        .slice(0, 12)
        .map((e) => {
          const t = new Date(e.time).toLocaleTimeString("ar-EG");
          let cmd;
          if (e.error) {
            cmd = `<span class="err" title="${esc(e.error)}">⚠ خطأ AI</span>`;
          } else if (e.command) {
            cmd = `<span class="cmd">${esc(e.command)}</span>`;
          } else {
            cmd = `<span class="none">تجاهل</span>`;
          }
          return `<tr><td>${t}</td><td class="msg">${esc(e.text)}</td><td>${cmd}</td></tr>`;
        })
        .join("");
    } catch { /* البوت ممكن يكون انحذف */ }
  };
  update();
  logTimers[botId] = setInterval(update, 3000);
}

init();
