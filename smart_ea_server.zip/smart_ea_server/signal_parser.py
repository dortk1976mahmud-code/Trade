# -*- coding: utf-8 -*-
"""
منطق تحليل رسائل التداول (مسار سريع محلي + DeepSeek AI).
موديول مستقل تستخدمه لوحة التحكم لأي عدد من البوتات بنفس الوقت.
"""

import re
import json
import logging
import requests

log = logging.getLogger("signal_parser")

# ------------------------ كلمات المسار السريع (بدون AI) ------------------------
CLOSE_ALL_WORDS = ["اغلاق الكل", "سكر الكل", "أغلق الكل", "close all", "اقفل الكل",
                   "اغلقو الكل", "سكرو الكل", "اغلاق كل الصفقات", "اغلقو كل الصفقات"]
CLOSE_NOW_WORDS = [
    "اغلاق الصفقة الان", "اغلاق الصفقه الان", "أغلق الصفقة الان",
    "سكر الصفقة", "اقفل الصفقة", "close now", "close position",
    "اغلقو الصفقة", "اغلقو الصفقه", "واغلقو الصفقة", "واغلقو الصفقه",
    "اغلق الصفقة", "اغلق الصفقه", "أغلقو الصفقة", "سكرو الصفقة", "اقفلو الصفقة",
]

# كلمات تدل على إغلاق جزئي - أول صفقة فقط (وترك الباقي مفتوح)
FIRST_TRADE_WORDS = [
    "الصفقة الاولى", "الصفقه الاولى", "الصفقة الأولى", "الصفقه الأولى",
    "اول صفقة", "أول صفقة", "اول صفقه", "الاولى فقط", "الصفقة الاولي",
]
# كلمات تدل على إغلاق آخر صفقة
LAST_TRADE_WORDS = [
    "الصفقة الاخيرة", "الصفقه الاخيرة", "الصفقة الأخيرة", "اخر صفقة", "آخر صفقة",
]
# كلمات التعزيز (فتح صفقة إضافية بنفس الاتجاه)
REINFORCE_WORDS = ["تعزيز", "نعزز", "سنعزز", "عزز", "عززو", "اضافة صفقة", "صفقة اضافية"]
# صيغ الوعد المستقبلي للتعزيز - إعلان نية مش أمر تنفيذ
FUTURE_REINFORCE_WORDS = ["سنعزز", "سوف نعزز", "راح نعزز", "بنعزز", "رح نعزز", "سنقوم بتعزيز"]
# كلمات تدل على ترك/إبقاء صفقة (مو أمر فتح)
KEEP_WORDS = ["اترك", "اتركو", "خلو", "خليك", "ابقو", "نترك", "دعو"]
MOVE_SL_ENTRY_WORDS = [
    "نقل الوقف الى الدخول", "نقل الوقف الى سعر الدخول", "الوقف على الدخول",
    "ستوب على الدخول", "خساره صفر", "بريك ايفن", "break even",
]
SL_UPDATE_WORDS = ["الاستوب", "الستوب", "وقف الخسارة", "الوقف", "ستوب", "استوب"]
OPEN_TRADE_HINT_WORDS = ["شراء", "بيع", "buy", "sell"]

DEFAULT_SYMBOL_MAP = {
    "ذهب": "GOLD", "الذهب": "GOLD", "gold": "GOLD", "xauusd": "GOLD",
    "فضة": "XAGUSD", "الفضة": "XAGUSD",
    "يورو": "EURUSD", "اليورو": "EURUSD",
    "باوند": "GBPUSD", "الباوند": "GBPUSD",
    "بيتكوين": "BTCUSD",
    "نفط": "USOIL", "النفط": "USOIL",
}


def extract_first_number(text: str):
    m = re.search(r"(\d+(?:\.\d+)?)", text)
    return float(m.group(1)) if m else None


def find_symbol(text: str, symbol_map: dict):
    text_l = text.lower()
    for key, symbol in symbol_map.items():
        if key.lower() in text_l:
            return symbol
    return None


def fast_parse(text: str, symbol_map: dict):
    """مسار سريع محلي (بدون شبكة) للأوامر الحرجة: إغلاق / نقل الوقف / تحديث الوقف."""
    t_low = text.lower().strip()

    has_close = (any(w in t_low for w in CLOSE_ALL_WORDS)
                 or any(w in t_low for w in CLOSE_NOW_WORDS))

    # مهم جداً: الإغلاق الجزئي يُفحص قبل الإغلاق الكامل.
    # "اغلقو الصفقة الاولى واتركو صفقة التعزيز" لازم تسكّر وحدة بس،
    # مو كل الصفقات (وإلا منسكّر صفقة القناة قالت اتركوها)
    if has_close and any(w in t_low for w in FIRST_TRADE_WORDS):
        return {"action": "close_first", "symbol": find_symbol(text, symbol_map), "count": 1}

    if has_close and any(w in t_low for w in LAST_TRADE_WORDS):
        return {"action": "close_last", "symbol": find_symbol(text, symbol_map), "count": 1}

    if any(w in t_low for w in CLOSE_ALL_WORDS):
        return {"action": "close_all"}

    if any(w in t_low for w in CLOSE_NOW_WORDS):
        symbol = find_symbol(text, symbol_map)
        return {"action": "close", "symbol": symbol} if symbol else {"action": "close_all"}

    if any(w in t_low for w in MOVE_SL_ENTRY_WORDS):
        symbol = find_symbol(text, symbol_map)
        return {"action": "move_sl_entry", "symbol": symbol}

    if not any(w in t_low for w in OPEN_TRADE_HINT_WORDS):
        if any(w in t_low for w in SL_UPDATE_WORDS):
            number = extract_first_number(text)
            if number is not None:
                symbol = find_symbol(text, symbol_map)
                return {"action": "update_sl", "symbol": symbol, "sl": number}

    return None


def build_ai_system_prompt(symbol_map: dict):
    unique_symbols = sorted(set(symbol_map.values()))
    symbols_line = "، ".join(unique_symbols) if unique_symbols else "GOLD"
    return f"""أنت مصنّف رسائل لقناة إشارات تداول عربية. مهمتك تحويل الرسالة إلى أمر JSON
واحد فقط، بدون أي نص إضافي أو شرح أو Markdown.

الرموز المسموحة (أسماء الأدوات عند وسيط المستخدم): {symbols_line}

════════════════ طريقة التفكير - اتبعها بالترتيب ════════════════

【الخطوة 1】 هل الرسالة أمر تنفيذ، أم مجرد كلام؟

كلام (ليس أمراً) → {{"action":"none"}}:
  • تحليل أو رأي في السوق: "الذهب سلبي"، "الاتجاه هابط"، "السعر في تجميع"
  • توقع: "متوقع نزول"، "قد يعود السعر"، "احتمال يختبر المقاومة"
  • تحذير أو نهي: "لا احد يشتري"، "خطر"، "لا تدخلوا الان"
  • شرط مستقبلي: "اذا اخترق X ندخل"، "انتظرو اعادة الاختبار"، "عند وصول السعر"
  • وعد مستقبلي: "سنعزز"، "سندخل"، "سنراقب"، "راح نشوف"
  • تهيئة: "استعدوا"، "جاهزين"، "ركزوا"
  • تعليق على نتيجة: "الحمدلله ربحنا"، "ضرب الهدف"، "تم بنجاح"
  • ترويج أو روابط أو تحية: "رابط التسجيل"، "بسم الله"، "تفاصيل الصفقة"

أمر تنفيذ → أكمل للخطوة 2

【الخطوة 2】 حدّد نوع الأمر بالضبط:

  أ) إغلاق كل الصفقات        → close_all
     "اغلاق الكل"، "اغلاق الصفقة الان"، "سكروا كل شي"

  ب) إغلاق أقدم صفقة فقط     → close_first
     "اغلقوا الصفقة الاولى"، "سكروا اول صفقة واتركوا الباقي"
     ⚠ لا تستخدم close_all هنا - المطلوب ترك باقي الصفقات مفتوحة

  ج) إغلاق آخر صفقة فقط      → close_last
     "اغلقوا الصفقة الاخيرة"، "سكروا آخر صفقة"

  د) نقل الوقف لسعر الدخول   → move_sl_entry
     "الوقف على الدخول"، "بريك ايفن"، "خساره صفر"
     (بدون رقم محدد)

  هـ) تعديل الوقف لرقم       → update_sl
     "الاستوب 4389"، "قدموا وقف الخسارة الى 4364"
     (لازم رقم صريح)

  و) تعديل الهدف لرقم        → update_tp
     "الهدف 4444"، "تم تعديل الهدف الى 4380"

  ز) دخول جديد               → open
     "بيع الذهب الان"، "شراء الذهب الان 4426"

  ح) إضافة لصفقة قائمة       → reinforce
     "عززوا بيع"، "ادخلوا صفقة اضافية بيع الان"
     ⚠ فقط بصيغة الأمر. "سنعزز" وعد مستقبلي → راجع الخطوة 1

【الخطوة 3】 تحقق قبل الإخراج:

  • open أو reinforce: لازم (1) اسم الأداة مذكور صراحة + (2) صيغة أمر فوري.
    ناقص أي واحد → {{"action":"none"}}
    ممنوع تخمين الأداة من سياق رسائل سابقة.
  • update_sl أو update_tp: لازم رقم صريح. ما فيه رقم → {{"action":"none"}}
  • رسالة فيها أكثر من أمر: خُذ الأمر الرئيسي الفعلي فقط.
    مثال: "الاستوب 4389 / سنعزز بيع" → الأمر الفعلي هو update_sl
    (لأن "سنعزز" وعد مستقبلي مش تنفيذ)

════════════════ الأشكال المسموحة ════════════════

{{"action":"open","side":"buy","symbol":"GOLD","sl":4280,"tp":4380}}
{{"action":"open","side":"sell","symbol":"GOLD","sl":null,"tp":null}}
{{"action":"reinforce","side":"sell","symbol":"GOLD","sl":4389,"tp":null}}
{{"action":"close_all"}}
{{"action":"close","symbol":"GOLD"}}
{{"action":"close_first","symbol":"GOLD","count":1}}
{{"action":"close_last","symbol":"GOLD","count":1}}
{{"action":"move_sl_entry","symbol":null}}
{{"action":"update_sl","symbol":"GOLD","sl":4364}}
{{"action":"update_tp","symbol":"GOLD","tp":4380}}
{{"action":"none"}}

════════════════ أمثلة حقيقية من هذه القناة ════════════════

"بيع الذهب الان صفقة واحده فقط اقل لوت 4376"
→ {{"action":"open","side":"sell","symbol":"GOLD","sl":null,"tp":null}}
(أمر فوري + الأداة صريحة. الرقم 4376 سعر الدخول وليس هدفاً أو وقفاً)

"📢 #صفقة_على_الذهب
#شراء_الذهب (XAUUSD)الان $4426
#هدف الصفقة -----------> $4444
#ايقاف_الخسارة $4412"
→ {{"action":"open","side":"buy","symbol":"GOLD","sl":4412,"tp":4444}}

"شباب ايقاف الخسارة الاستوب $4389"
→ {{"action":"update_sl","symbol":"GOLD","sl":4389}}

"شباب ايقاف الخسارة الاستوب $4389
سنعزز بيع"
→ {{"action":"update_sl","symbol":"GOLD","sl":4389}}
(الأمر الفعلي تحديث الوقف. "سنعزز" وعد مستقبلي فلا يُنفَّذ)

"عززوا بيع الذهب الان"
→ {{"action":"reinforce","side":"sell","symbol":"GOLD","sl":null,"tp":null}}

"يلاه شباب سيصل السعر الي $4366 واغلقو الصفقة الاولى واتركو صفقة التعزيز"
→ {{"action":"close_first","symbol":"GOLD","count":1}}
(إغلاق أقدم صفقة فقط. close_all خطأ فادح لأنه يسكّر صفقة التعزيز المطلوب تركها)

"اغلاق الصفقة الان بربح 80 نقطة"
→ {{"action":"close_all"}}
(الربح المذكور معلومة للقارئ، لا تتحقق منه)

"نقل الوقف الى سعر الدخول"
→ {{"action":"move_sl_entry","symbol":null}}

"شباب الذهب سلبي لا احد يشتري خطررر فقط انتظرو اعادة اختبار للمقاومة والدخول
اقل لوت بيع من قرب المقاومة صفقة واحده الاستوب $4424 هدف مفتوح"
→ {{"action":"none"}}
(خطة مشروطة: "انتظرو" + "لا احد يشتري". لم يحن وقت التنفيذ)

"شباب الذي ضرب عنده استوب عاود البيع الان 4471$"
→ {{"action":"none"}}
(لم تُذكر الأداة صراحة. ممنوع التخمين)

"سننتظر ثبات السعر فوق 4330 لتاكيد الارتفاع"
→ {{"action":"none"}}

"استعدووو" / "تفاصيل الصفقة 👆" / "بسم الله" / "رابط التسجيل ..."
→ {{"action":"none"}}

════════════════ قواعد نهائية ════════════════
• أخرج JSON واحداً فقط، بدون أي شرح أو تعليق.
• عند الشك بين تنفيذ أمر أو تجاهله، اختر {{"action":"none"}}.
  تفويت إشارة خسارة صغيرة، وتنفيذ أمر خاطئ خسارة مال حقيقي.
"""
DEEPSEEK_URL = "https://api.deepseek.com/chat/completions"
DEEPSEEK_MODEL = "deepseek-chat"


def call_deepseek(text: str, api_key: str, symbol_map: dict, timeout: int = 8):
    """يرجع (result_dict_or_None, error_message_or_None)."""
    if not api_key:
        return None, "لا يوجد مفتاح DeepSeek مضبوط"

    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    payload = {
        "model": DEEPSEEK_MODEL,
        "messages": [
            {"role": "system", "content": build_ai_system_prompt(symbol_map)},
            {"role": "user", "content": text},
        ],
        "temperature": 0,
        "max_tokens": 150,
    }
    try:
        resp = requests.post(DEEPSEEK_URL, headers=headers, json=payload, timeout=timeout)
    except requests.exceptions.Timeout:
        return None, "انتهت مهلة الاتصال بـ DeepSeek"
    except requests.exceptions.ConnectionError as e:
        return None, f"تعذر الاتصال بـ DeepSeek (شبكة/DNS): {e}"
    except Exception as e:
        return None, f"خطأ اتصال بـ DeepSeek: {e}"

    if resp.status_code == 401:
        return None, "مفتاح DeepSeek غير صحيح (401)"
    if resp.status_code == 402:
        return None, "رصيد DeepSeek خلص (402)"
    if resp.status_code == 429:
        return None, "تجاوزت حد طلبات DeepSeek (429)"
    if resp.status_code != 200:
        return None, f"DeepSeek رجّع HTTP {resp.status_code}: {resp.text[:120]}"

    try:
        content = resp.json()["choices"][0]["message"]["content"].strip()
        content = content.replace("```json", "").replace("```", "").strip()
        return json.loads(content), None
    except (KeyError, IndexError, json.JSONDecodeError) as e:
        return None, f"رد DeepSeek بصيغة غير متوقعة: {e}"


# كلمات تدل على أن الدخول فوري الآن (لازم وحدة منها على الأقل بأمر الفتح)
IMMEDIATE_WORDS = [
    "الان", "الآن", "حالا", "حالاً", "فورا", "فوراً",
    "ادخل", "أدخل", "ادخلو", "دخول الان", "now",
]

# كلمات تدل على أن الرسالة خطة/تحليل/شرط مستقبلي وليست أمر تنفيذ
CONDITIONAL_WORDS = [
    "انتظر", "انتظرو", "ننتظر", "سننتظر", "استعد", "استعدو", "راقب", "نراقب",
    "اذا ", "إذا ", "لو ", "عند وصول", "عند اختراق", "عند كسر", "بحال",
    "متوقع", "نتوقع", "توقع", "احتمال", "ممكن", "قد ي", "سيناريو",
    "لا احد", "لا أحد", "ما حدا", "لا تدخل", "لا تشتر", "لا تبيع", "تجنب",
    "مازال", "ما زال", "لسا", "خطر", "حذر", "wait", "if ",
]


def _has_immediate_entry(text: str) -> bool:
    """
    يتحقق إن الرسالة أمر دخول فوري فعلاً، مش تحليل أو خطة مشروطة.
    مثال يُرفض: "انتظرو اعادة اختبار للمقاومة والدخول اقل لوت بيع..."
    مثال يُقبل: "بيع الذهب الان 4474$"
    """
    t = text.lower()

    # أي كلمة شرط/انتظار -> الرسالة خطة مستقبلية، مو أمر تنفيذ
    if any(w in t for w in CONDITIONAL_WORDS):
        return False

    # علامة فورية صريحة
    if any(w in t for w in IMMEDIATE_WORDS):
        return True

    # أو الصيغة المنظمة الكاملة (سعر + هدف + وقف) اللي بترسلها القناة كإشارة رسمية
    has_target = "هدف" in t or "تارجت" in t or "tp" in t
    has_stop = "ايقاف" in t or "إيقاف" in t or "استوب" in t or "وقف" in t or "sl" in t
    return has_target and has_stop


def _symbol_explicitly_mentioned(text: str, symbol: str, symbol_map: dict) -> bool:
    """
    يتحقق إن الرمز اللي رجّعه الذكاء الاصطناعي مذكور فعلاً بنص الرسالة الأصلية
    (سواء بالاسم العربي أو بالرمز الإنجليزي نفسه). حماية صارمة عشان الذكاء
    الاصطناعي ما يخترع رمز لرسالة غامضة ما ذكرت أداة صراحة.
    """
    if not symbol:
        return False
    text_l = text.lower()
    if symbol.lower() in text_l:
        return True
    for key, val in symbol_map.items():
        if val == symbol and key.lower() in text_l:
            return True
    return False


def ai_parse(text: str, api_key: str, symbol_map: dict):
    """يرجع (result_dict_or_None, error_message_or_None)."""
    result, error = call_deepseek(text, api_key, symbol_map)
    if error:
        log.error("فشل تحليل DeepSeek: %s", error)
        return None, error
    if not isinstance(result, dict) or result.get("action") in (None, "none"):
        return None, None  # قرار سليم من الـAI إن الرسالة مو أمر تداول

    # حاجز أمان صارم: أمر فتح صفقة لازم يكون الرمز مذكور صراحة بالرسالة،
    # وإلا نرفضه كلياً (بغض النظر عن رأي الذكاء الاصطناعي) - أفضل نتجاهل
    # رسالة غامضة على أن نفتح صفقة على أداة خاطئة أو مخترعة
    # حواجز أمان صارمة لأي أمر يفتح صفقة (دخول جديد أو تعزيز).
    # تُطبق بغض النظر عن رأي الذكاء الاصطناعي.
    if result.get("action") in ("open", "reinforce"):
        symbol = result.get("symbol")
        if not _symbol_explicitly_mentioned(text, symbol, symbol_map):
            log.warning(
                "تم رفض أمر فتح: الرمز '%s' غير مذكور صراحة بالرسالة، تم تجاهله: %s",
                symbol, text[:100],
            )
            return None, None

        # حاجز ثاني: لازم تكون الرسالة أمر دخول فوري، مش تحليل أو خطة مشروطة
        # (مثال مرفوض: "انتظرو اعادة اختبار للمقاومة ثم الدخول بيع...")
        if not _has_immediate_entry(text):
            log.warning(
                "تم رفض أمر فتح: الرسالة خطة/تحليل مش أمر دخول فوري، تم تجاهلها: %s",
                text[:100],
            )
            return None, None

        t = text.lower()

        # "اترك/ابقِ صفقة التعزيز" إبقاء مش فتح
        if any(k in t for k in KEEP_WORDS):
            log.warning("تم رفض أمر فتح: الرسالة إبقاء صفقة مش فتح: %s", text[:100])
            return None, None

        # تعزيز: صفقة إضافية بنفس الاتجاه رغم وجود صفقة مفتوحة.
        # لازم تكون بصيغة الأمر (عززوا) مش الوعد المستقبلي (سنعزز).
        if any(w in t for w in REINFORCE_WORDS):
            if any(w in t for w in FUTURE_REINFORCE_WORDS):
                log.warning(
                    "تم رفض أمر تعزيز: وعد مستقبلي مش أمر تنفيذ: %s", text[:100]
                )
                return None, None
            result["action"] = "reinforce"
            log.info("أمر تعزيز (صفقة إضافية بنفس الاتجاه)")
        elif result.get("action") == "reinforce":
            # الذكاء الاصطناعي قال تعزيز بس ما فيه أي كلمة تعزيز بالرسالة
            log.warning("تم تحويل تعزيز غير مبرر إلى دخول عادي: %s", text[:100])
            result["action"] = "open"

    return result, None


def cmd_to_line(cmd: dict):
    """يحوّل أمر (dict) لسطر نصي بسيط يفهمه الـEA."""
    if not isinstance(cmd, dict):
        return None
    action = cmd.get("action")

    if action in ("open", "reinforce"):
        side = str(cmd.get("side") or "").upper()
        if side not in ("BUY", "SELL"):
            return None
        symbol = cmd.get("symbol") or "NA"
        sl = cmd.get("sl")
        tp = cmd.get("tp")
        sl_s = "NA" if sl in (None, "") else str(sl)
        tp_s = "NA" if tp in (None, "") else str(tp)
        verb = "REINFORCE" if action == "reinforce" else "OPEN"
        return f"{verb}|{symbol}|{side}|{sl_s}|{tp_s}"

    if action == "close_all":
        return "CLOSE_ALL"

    if action == "close":
        return f"CLOSE|{cmd.get('symbol') or 'NA'}"

    if action == "close_first":
        n = cmd.get("count") or 1
        return f"CLOSE_FIRST|{cmd.get('symbol') or 'NA'}|{int(n)}"

    if action == "close_last":
        n = cmd.get("count") or 1
        return f"CLOSE_LAST|{cmd.get('symbol') or 'NA'}|{int(n)}"

    if action == "move_sl_entry":
        return f"MOVE_SL_ENTRY|{cmd.get('symbol') or 'NA'}"

    if action == "update_sl":
        sl = cmd.get("sl")
        if sl in (None, ""):
            return None
        return f"UPDATE_SL|{cmd.get('symbol') or 'NA'}|{sl}"

    if action == "update_tp":
        tp = cmd.get("tp")
        if tp in (None, ""):
            return None
        return f"UPDATE_TP|{cmd.get('symbol') or 'NA'}|{tp}"

    return None
